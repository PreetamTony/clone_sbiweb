"use client";

import React, { createContext, useState, useContext, useEffect } from "react";

// Define supported languages
export const languages = [
  { code: "en", name: "English" },
  { code: "hi", name: "हिंदी (Hindi)" },
  { code: "bn", name: "বাংলা (Bengali)" },
  { code: "ta", name: "தமிழ் (Tamil)" },
  { code: "te", name: "తెలుగు (Telugu)" },
  { code: "mr", name: "मराठी (Marathi)" },
  { code: "gu", name: "ગુજરાતી (Gujarati)" },
  { code: "kn", name: "ಕನ್ನಡ (Kannada)" },
  { code: "ml", name: "മലയാളം (Malayalam)" },
  { code: "pa", name: "ਪੰਜਾਬੀ (Punjabi)" },
];

// Define translations for different languages
// In a real app, this would be more extensive and loaded from external files
export const translations: Record<string, Record<string, string>> = {
  "home.title": {
    en: "Book Your Train Tickets with Ease",
    hi: "आसानी से अपने ट्रेन टिकट बुक करें",
    bn: "সহজেই আপনার ট্রেন টিকেট বুক করুন",
    ta: "எளிதாக உங்கள் ரயில் டிக்கெட்டுகளை முன்பதிவு செய்யுங்கள்",
    te: "సులభంగా మీ రైలు టికెట్లను బుక్ చేసుకోండి",
    mr: "सहजपणे आपले ट्रेन तिकीट बुक करा",
    gu: "સરળતાથી તમારી ટ્રેન ટિકિટ બુક કરો",
    kn: "ಸುಲಭವಾಗಿ ನಿಮ್ಮ ರೈಲು ಟಿಕೆಟ್‌ಗಳನ್ನು ಬುಕ್ ಮಾಡಿ",
    ml: "എളുപ്പത്തിൽ നിങ്ങളുടെ ട്രെയിൻ ടിക്കറ്റുകൾ ബുക്ക് ചെയ്യുക",
    pa: "ਆਸਾਨੀ ਨਾਲ ਆਪਣੀਆਂ ਰੇਲ ਟਿਕਟਾਂ ਬੁੱਕ ਕਰੋ",
  },
  "home.subtitle": {
    en: "Experience seamless train booking with our improved platform",
    hi: "हमारे बेहतर प्लेटफॉर्म के साथ सुचारू ट्रेन बुकिंग का अनुभव करें",
    bn: "আমাদের উন্নত প্ল্যাটফর্মের সাথে নিরবচ্ছিন্ন ট্রেন বুকিং অভিজ্ঞতা নিন",
    ta: "எங்கள் மேம்படுத்தப்பட்ட தளத்துடன் தடையற்ற ரயில் முன்பதிவை அனுபவிக்கவும்",
    te: "మా మెరుగుపరచబడిన ప్లాట్‌ఫారమ్‌తో సజావుగా రైలు బుకింగ్‌ను అనుభవించండి",
    mr: "आमच्या सुधारित प्लॅटफॉर्मसह सहज ट्रेन बुकिंग अनुभवा",
    gu: "અમારા સુધારેલા પ્લેટફોર્મ સાથે સરળ ટ્રેન બુકિંગનો અનુભવ કરો",
    kn: "ನಮ್ಮ ಸುಧಾರಿತ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನೊಂದಿಗೆ ನಿರಂತರ ರೈಲು ಬುಕ್ಕಿಂಗ್ ಅನುಭವಿಸಿ",
    ml: "ഞങ്ങളുടെ മെച്ചപ്പെടുത്തിയ പ്ലാറ്റ്‌ഫോമിൽ തടസ്സമില്ലാത്ത ട്രെയിൻ ബുക്കിംഗ് അനുഭവിക്കുക",
    pa: "ਸਾਡੇ ਬਿਹਤਰ ਪਲੇਟਫਾਰਮ ਨਾਲ ਨਿਰਵਿਘਨ ਰੇਲ ਬੁਕਿੰਗ ਦਾ ਅਨੁਭਵ ਕਰੋ",
  },
  "nav.home": {
    en: "Home",
    hi: "होम",
    bn: "হোম",
    ta: "முகப்பு",
    te: "హోమ్",
    mr: "होम",
    gu: "હોમ",
    kn: "ಹೋಮ್",
    ml: "ഹോം",
    pa: "ਹੋਮ",
  },
  "nav.trains": {
    en: "Trains",
    hi: "ट्रेनें",
    bn: "ট্রেন",
    ta: "ரயில்கள்",
    te: "రైళ్లు",
    mr: "ट्रेन",
    gu: "ટ્રેન",
    kn: "ರೈಲುಗಳು",
    ml: "ട്രെയിനുകൾ",
    pa: "ਰੇਲਗੱਡੀਆਂ",
  },
  "nav.bookTicket": {
    en: "Book Ticket",
    hi: "टिकट बुक करें",
    bn: "টিকিট বুক করুন",
    ta: "டிக்கெட் முன்பதிவு",
    te: "టికెట్ బుక్ చేయండి",
    mr: "तिकीट बुक करा",
    gu: "ટિકિટ બુક કરો",
    kn: "ಟಿಕೆಟ್ ಬುಕ್ ಮಾಡಿ",
    ml: "ടിക്കറ്റ് ബുക്ക് ചെയ്യുക",
    pa: "ਟਿਕਟ ਬੁੱਕ ਕਰੋ",
  },
  "nav.pnrStatus": {
    en: "PNR Status",
    hi: "पीएनआर स्थिति",
    bn: "পিএনআর স্ট্যাটাস",
    ta: "பிஎன்ஆர் நிலை",
    te: "పిఎన్ఆర్ స్థితి",
    mr: "पीएनआर स्थिती",
    gu: "PNR સ્થિતિ",
    kn: "ಪಿಎನ್ಆರ್ ಸ್ಥಿತಿ",
    ml: "PNR സ്റ്റാറ്റസ്",
    pa: "ਪੀਐਨਆਰ ਸਟੇਟਸ",
  },
  "nav.trackTrain": {
    en: "Track Your Train",
    hi: "अपनी ट्रेन ट्रैक करें",
    bn: "আপনার ট্রেন ট্র্যাক করুন",
    ta: "உங்கள் ரயிலைக் கண்காணிக்கவும்",
    te: "మీ రైలును ట్రాక్ చేయండి",
    mr: "आपली ट्रेन ट्रॅक करा",
    gu: "તમારી ટ્રેન ટ્રેક કરો",
    kn: "ನಿಮ್ಮ ರೈಲನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ",
    ml: "നിങ്ങളുടെ ട്രെയിൻ ട്രാക്ക് ചെയ്യുക",
    pa: "ਆਪਣੀ ਰੇਲਗੱਡੀ ਨੂੰ ਟਰੈਕ ਕਰੋ",
  },
  "login": {
    en: "Login",
    hi: "लॉग इन",
    bn: "লগইন",
    ta: "உள்நுழைய",
    te: "లాగిన్",
    mr: "लॉग इन",
    gu: "લોગિન",
    kn: "ಲಾಗಿನ್",
    ml: "ലോഗിൻ",
    pa: "ਲਾਗਇਨ",
  },
  "register": {
    en: "Register",
    hi: "रजिस्टर",
    bn: "রেজিস্টার",
    ta: "பதிவு",
    te: "నమోదు",
    mr: "नोंदणी",
    gu: "રજિસ્ટર",
    kn: "ನೋಂದಣಿ",
    ml: "രജിസ്റ്റർ",
    pa: "ਰਜਿਸਟਰ",
  },
};

// Define the context type
interface LanguageContextType {
  language: string;
  setLanguage: (code: string) => void;
  t: (key: string) => string;
  languages: { code: string; name: string }[];
}

// Create the context
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Language Provider component
export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState("en");

  // Initialize language from localStorage on client
  useEffect(() => {
    const savedLanguage = localStorage.getItem("language");
    if (savedLanguage) {
      setLanguage(savedLanguage);
    }
  }, []);

  // Save language to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("language", language);
  }, [language]);

  // Translation function
  const t = (key: string): string => {
    if (!translations[key]) {
      return key;
    }

    return translations[key][language] || translations[key]["en"] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, languages }}>
      {children}
    </LanguageContext.Provider>
  );
}

// Custom hook to use the language context
export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
