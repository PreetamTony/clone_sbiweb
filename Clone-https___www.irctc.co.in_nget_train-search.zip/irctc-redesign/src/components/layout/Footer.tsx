import Link from "next/link";
import { Facebook, Twitter, Instagram, Linkedin, Youtube } from "lucide-react";

interface FooterSection {
  title: string;
  links: {
    name: string;
    href: string;
  }[];
}

const footerSections: FooterSection[] = [
  {
    title: "Trains",
    links: [
      { name: "Book Ticket", href: "/trains/booking" },
      { name: "PNR Status", href: "/trains/pnr-status" },
      { name: "Train Schedule", href: "/trains/schedule" },
      { name: "Track Your Train", href: "/trains/track" },
      { name: "Cancellations", href: "/trains/cancellations" },
    ],
  },
  {
    title: "Travel",
    links: [
      { name: "Hotels", href: "/hotels" },
      { name: "Flights", href: "/flights" },
      { name: "Bus", href: "/bus" },
      { name: "Holiday Packages", href: "/holidays" },
      { name: "Travel Insurance", href: "/insurance" },
    ],
  },
  {
    title: "Services",
    links: [
      { name: "e-Catering", href: "/services/catering" },
      { name: "IRCTC eWallet", href: "/services/ewallet" },
      { name: "IRCTC Rail Connect App", href: "/services/rail-connect" },
      { name: "Loyalty Program", href: "/services/loyalty" },
      { name: "Group Booking", href: "/services/group-booking" },
    ],
  },
  {
    title: "Help & Support",
    links: [
      { name: "Contact Us", href: "/support/contact" },
      { name: "FAQs", href: "/support/faqs" },
      { name: "Terms of Service", href: "/support/terms" },
      { name: "Privacy Policy", href: "/support/privacy" },
      { name: "Refund Rules", href: "/support/refund" },
    ],
  },
];

const socialLinks = [
  { icon: Facebook, href: "https://www.facebook.com/IRCTCofficial" },
  { icon: Twitter, href: "https://twitter.com/IRCTCofficial" },
  { icon: Instagram, href: "https://www.instagram.com/irctc.official" },
  { icon: Linkedin, href: "https://www.linkedin.com/company/irctcofficial" },
  { icon: Youtube, href: "https://www.youtube.com/c/IRCTCOFFICIAL" },
];

export function Footer() {
  return (
    <footer className="bg-muted/50">
      <div className="container py-10 md:py-16">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4 lg:gap-12">
          {footerSections.map((section, index) => (
            <div key={index}>
              <h3 className="mb-4 text-base font-medium">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link
                      href={link.href}
                      className="text-sm text-muted-foreground hover:text-primary hover:underline"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-6 border-t border-border pt-8 md:flex-row">
          <div className="flex items-center gap-4">
            {socialLinks.map((social, index) => {
              const Icon = social.icon;
              return (
                <Link
                  key={index}
                  href={social.href}
                  className="rounded-full bg-primary/10 p-2 text-primary hover:bg-primary/20"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Icon className="h-5 w-5" />
                  <span className="sr-only">{social.icon.name}</span>
                </Link>
              );
            })}
          </div>

          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} Indian Railway Catering and Tourism Corporation Ltd. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
