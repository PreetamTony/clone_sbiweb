"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Menu, X, ChevronDown, User, LogIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ThemeToggle } from "@/components/theme/theme-toggle";
import { LanguageSwitcher } from "@/components/language/language-switcher";
import { useLanguage } from "@/components/language/language-provider";

interface NavItem {
  key: string;
  href: string;
  submenu?: { key: string; href: string }[];
}

const navItems: NavItem[] = [
  {
    key: "nav.home",
    href: "/",
  },
  {
    key: "nav.trains",
    href: "/trains",
    submenu: [
      { key: "nav.bookTicket", href: "/trains/booking" },
      { key: "nav.pnrStatus", href: "/trains/pnr-status" },
      { key: "nav.trainSchedule", href: "/trains/schedule" },
      { key: "nav.trackTrain", href: "/trains/track" },
    ],
  },
  {
    key: "nav.hotels",
    href: "/hotels",
  },
  {
    key: "nav.flights",
    href: "/flights",
  },
  {
    key: "nav.bus",
    href: "/bus",
  },
  {
    key: "nav.holidays",
    href: "/holidays",
  },
  {
    key: "nav.support",
    href: "/support",
  },
];

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { t } = useLanguage();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6 md:gap-8 lg:gap-10">
          <Link href="/" className="flex items-center space-x-2">
            <Image
              src="/irctc-logo.svg"
              alt="IRCTC Logo"
              width={120}
              height={40}
              className="h-10 w-auto"
              priority
            />
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item, index) => (
              item.submenu ? (
                <DropdownMenu key={index}>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="group flex items-center gap-1 h-10">
                      {t(item.key)}
                      <ChevronDown className="h-4 w-4 opacity-50 group-hover:opacity-100" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-48">
                    {item.submenu.map((subItem, subIndex) => (
                      <DropdownMenuItem key={subIndex} asChild>
                        <Link href={subItem.href} className="w-full">
                          {t(subItem.key)}
                        </Link>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link
                  key={index}
                  href={item.href}
                  className="text-sm font-medium transition-colors hover:text-primary"
                >
                  {t(item.key)}
                </Link>
              )
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden md:flex items-center gap-2">
            <LanguageSwitcher />
            <ThemeToggle />
            <Link href="/login">
              <Button variant="ghost" size="sm" className="gap-1">
                <LogIn className="h-4 w-4" />
                {t("login")}
              </Button>
            </Link>
            <Link href="/register">
              <Button variant="default" size="sm" className="gap-1">
                <User className="h-4 w-4" />
                {t("register")}
              </Button>
            </Link>
          </div>

          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="pr-0">
              <div className="px-7">
                <Link
                  href="/"
                  className="flex items-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Image
                    src="/irctc-logo.svg"
                    alt="IRCTC Logo"
                    width={100}
                    height={30}
                    className="h-8 w-auto"
                  />
                </Link>
              </div>
              <nav className="mt-8 flex flex-col gap-4 pr-6">
                {navItems.map((item, index) => (
                  <div key={index} className="flex flex-col">
                    <Link
                      href={item.href}
                      className="text-base font-medium"
                      onClick={() => !item.submenu && setMobileMenuOpen(false)}
                    >
                      {t(item.key)}
                    </Link>
                    {item.submenu && (
                      <div className="ml-4 mt-2 flex flex-col gap-2">
                        {item.submenu.map((subItem, subIndex) => (
                          <Link
                            key={subIndex}
                            href={subItem.href}
                            className="text-sm text-muted-foreground hover:text-primary"
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            {t(subItem.key)}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </nav>
              <div className="mt-6 flex flex-col gap-2 pr-6">
                <div className="mb-2 flex justify-between">
                  <LanguageSwitcher />
                  <ThemeToggle />
                </div>
                <Link
                  href="/login"
                  className="w-full"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <LogIn className="h-4 w-4" />
                    {t("login")}
                  </Button>
                </Link>
                <Link
                  href="/register"
                  className="w-full"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Button className="w-full justify-start gap-2">
                    <User className="h-4 w-4" />
                    {t("register")}
                  </Button>
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
