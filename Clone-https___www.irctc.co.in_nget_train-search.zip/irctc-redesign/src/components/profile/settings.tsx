"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Check, Info, Globe, Bell, Shield, Moon, Save } from "lucide-react";

interface UserSettings {
  language: string;
  emailNotifications: boolean;
  smsNotifications: boolean;
  priceAlerts: boolean;
  statusUpdates: boolean;
  twoFactorAuth: boolean;
  loginAlerts: boolean;
  darkMode: boolean;
  autoFill: boolean;
}

const defaultSettings: UserSettings = {
  language: "en",
  emailNotifications: true,
  smsNotifications: true,
  priceAlerts: true,
  statusUpdates: true,
  twoFactorAuth: false,
  loginAlerts: true,
  darkMode: false,
  autoFill: true,
};

const languages = [
  { value: "en", label: "English" },
  { value: "hi", label: "हिंदी (Hindi)" },
  { value: "bn", label: "বাংলা (Bengali)" },
  { value: "ta", label: "தமிழ் (Tamil)" },
  { value: "te", label: "తెలుగు (Telugu)" },
  { value: "mr", label: "मराठी (Marathi)" },
  { value: "gu", label: "ગુજરાતી (Gujarati)" },
  { value: "kn", label: "ಕನ್ನಡ (Kannada)" },
  { value: "ml", label: "മലയാളം (Malayalam)" },
  { value: "pa", label: "ਪੰਜਾਬੀ (Punjabi)" },
];

export function Settings() {
  const [settings, setSettings] = useState<UserSettings>(defaultSettings);
  const [isSaved, setIsSaved] = useState(false);

  const handleSwitchChange = (name: keyof UserSettings) => {
    setSettings((prev) => ({
      ...prev,
      [name]: !prev[name],
    }));
    setIsSaved(false);
  };

  const handleSelectChange = (name: keyof UserSettings, value: string) => {
    setSettings((prev) => ({
      ...prev,
      [name]: value,
    }));
    setIsSaved(false);
  };

  const saveSettings = () => {
    // In a real app, this would make an API call to save user settings
    setIsSaved(true);

    // Reset the saved state after 3 seconds
    setTimeout(() => {
      setIsSaved(false);
    }, 3000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Language & Regional</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-6">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="language">Language</Label>
              <div className="text-sm text-muted-foreground">
                Select your preferred language for the interface
              </div>
            </div>
            <div className="w-full sm:w-52">
              <Select
                value={settings.language}
                onValueChange={(value) => handleSelectChange("language", value)}
              >
                <SelectTrigger id="language" className="w-full">
                  <Globe className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Select language" />
                </SelectTrigger>
                <SelectContent>
                  {languages.map((language) => (
                    <SelectItem key={language.value} value={language.value}>
                      {language.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Notifications</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="emailNotifications">Email Notifications</Label>
              <div className="text-sm text-muted-foreground">
                Receive booking confirmations, offers, and updates
              </div>
            </div>
            <Switch
              id="emailNotifications"
              checked={settings.emailNotifications}
              onCheckedChange={() => handleSwitchChange("emailNotifications")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="smsNotifications">SMS Notifications</Label>
              <div className="text-sm text-muted-foreground">
                Receive booking confirmations and journey updates via SMS
              </div>
            </div>
            <Switch
              id="smsNotifications"
              checked={settings.smsNotifications}
              onCheckedChange={() => handleSwitchChange("smsNotifications")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="priceAlerts">Price Alerts</Label>
              <div className="text-sm text-muted-foreground">
                Receive notifications when ticket prices drop for your saved routes
              </div>
            </div>
            <Switch
              id="priceAlerts"
              checked={settings.priceAlerts}
              onCheckedChange={() => handleSwitchChange("priceAlerts")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="statusUpdates">PNR & Train Status Updates</Label>
              <div className="text-sm text-muted-foreground">
                Get real-time updates about your journey and PNR status
              </div>
            </div>
            <Switch
              id="statusUpdates"
              checked={settings.statusUpdates}
              onCheckedChange={() => handleSwitchChange("statusUpdates")}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Security</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="twoFactorAuth">Two-Factor Authentication</Label>
              <div className="text-sm text-muted-foreground">
                Add an extra layer of security to your account
              </div>
            </div>
            <Switch
              id="twoFactorAuth"
              checked={settings.twoFactorAuth}
              onCheckedChange={() => handleSwitchChange("twoFactorAuth")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="loginAlerts">Login Alerts</Label>
              <div className="text-sm text-muted-foreground">
                Receive notifications when your account is accessed from a new device
              </div>
            </div>
            <Switch
              id="loginAlerts"
              checked={settings.loginAlerts}
              onCheckedChange={() => handleSwitchChange("loginAlerts")}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Preferences</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="darkMode">Dark Mode</Label>
              <div className="text-sm text-muted-foreground">
                Enable dark mode for a better viewing experience at night
              </div>
            </div>
            <Switch
              id="darkMode"
              checked={settings.darkMode}
              onCheckedChange={() => handleSwitchChange("darkMode")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="autoFill">Auto-fill Passenger Details</Label>
              <div className="text-sm text-muted-foreground">
                Automatically fill in saved passenger details when booking
              </div>
            </div>
            <Switch
              id="autoFill"
              checked={settings.autoFill}
              onCheckedChange={() => handleSwitchChange("autoFill")}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-end gap-4">
        {isSaved && (
          <div className="flex items-center gap-2 rounded-lg bg-green-100 px-4 py-2 text-sm text-green-800 dark:bg-green-900/30 dark:text-green-400">
            <Check className="h-4 w-4" />
            Settings saved successfully
          </div>
        )}
        <Button onClick={saveSettings} className="gap-2">
          <Save className="h-4 w-4" />
          Save Settings
        </Button>
      </div>
    </div>
  );
}
