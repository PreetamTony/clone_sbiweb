"use client";

import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Calendar,
  Edit,
  Plus,
  Trash,
  User
} from "lucide-react";

interface Passenger {
  id: string;
  name: string;
  age: number;
  gender: string;
  berth: string;
  idType: string;
  idNumber: string;
  isDefault: boolean;
}

// Mock passenger data
const mockPassengers: Passenger[] = [
  {
    id: "pass-1",
    name: "Rahul Sharma",
    age: 32,
    gender: "Male",
    berth: "Lower",
    idType: "Aadhaar",
    idNumber: "XXXX-XXXX-1234",
    isDefault: true,
  },
  {
    id: "pass-2",
    name: "Priya Sharma",
    age: 29,
    gender: "Female",
    berth: "Upper",
    idType: "Aadhaar",
    idNumber: "XXXX-XXXX-5678",
    isDefault: false,
  },
  {
    id: "pass-3",
    name: "Arjun Sharma",
    age: 8,
    gender: "Male",
    berth: "Side Lower",
    idType: "Aadhaar",
    idNumber: "XXXX-XXXX-9012",
    isDefault: false,
  },
];

export function SavedPassengers() {
  const [passengers, setPassengers] = useState<Passenger[]>(mockPassengers);
  const [isAddingPassenger, setIsAddingPassenger] = useState(false);
  const [editingPassenger, setEditingPassenger] = useState<Passenger | null>(null);

  // Form state for new/editing passenger
  const [formData, setFormData] = useState<Omit<Passenger, "id">>({
    name: "",
    age: 0,
    gender: "Male",
    berth: "No Preference",
    idType: "Aadhaar",
    idNumber: "",
    isDefault: false,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const resetForm = () => {
    setFormData({
      name: "",
      age: 0,
      gender: "Male",
      berth: "No Preference",
      idType: "Aadhaar",
      idNumber: "",
      isDefault: false,
    });
    setEditingPassenger(null);
  };

  const handleAddPassenger = () => {
    const newPassenger: Passenger = {
      id: `pass-${new Date().getTime()}`,
      ...formData,
    };

    // If the new passenger is set as default, unset default for all others
    if (newPassenger.isDefault) {
      setPassengers(
        passengers.map((p) => ({
          ...p,
          isDefault: false,
        }))
      );
    }

    setPassengers([...passengers, newPassenger]);
    setIsAddingPassenger(false);
    resetForm();
  };

  const handleEditPassenger = (passenger: Passenger) => {
    setEditingPassenger(passenger);
    setFormData({
      name: passenger.name,
      age: passenger.age,
      gender: passenger.gender,
      berth: passenger.berth,
      idType: passenger.idType,
      idNumber: passenger.idNumber,
      isDefault: passenger.isDefault,
    });
    setIsAddingPassenger(true);
  };

  const handleUpdatePassenger = () => {
    if (!editingPassenger) return;

    // If the edited passenger is set as default, unset default for all others
    if (formData.isDefault && !editingPassenger.isDefault) {
      setPassengers(
        passengers.map((p) => ({
          ...p,
          isDefault: false,
        }))
      );
    }

    setPassengers(
      passengers.map((p) =>
        p.id === editingPassenger.id ? { ...p, ...formData } : p
      )
    );

    setIsAddingPassenger(false);
    resetForm();
  };

  const handleDeletePassenger = (id: string) => {
    setPassengers(passengers.filter((p) => p.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingPassenger) {
      handleUpdatePassenger();
    } else {
      handleAddPassenger();
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle>Saved Passengers</CardTitle>
          <Dialog open={isAddingPassenger} onOpenChange={setIsAddingPassenger}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1">
                <Plus className="h-4 w-4" />
                Add Passenger
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingPassenger ? "Edit Passenger" : "Add New Passenger"}
                </DialogTitle>
                <DialogDescription>
                  {editingPassenger
                    ? "Update the passenger details below"
                    : "Fill in the passenger details to save for future bookings"}
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Passenger Name</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="age">Age</Label>
                      <Input
                        id="age"
                        name="age"
                        type="number"
                        value={formData.age.toString()}
                        onChange={handleInputChange}
                        min="1"
                        required
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="gender">Gender</Label>
                      <Select
                        value={formData.gender}
                        onValueChange={(value) => handleSelectChange("gender", value)}
                      >
                        <SelectTrigger id="gender">
                          <SelectValue placeholder="Select gender" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Male">Male</SelectItem>
                          <SelectItem value="Female">Female</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="berth">Berth Preference</Label>
                    <Select
                      value={formData.berth}
                      onValueChange={(value) => handleSelectChange("berth", value)}
                    >
                      <SelectTrigger id="berth">
                        <SelectValue placeholder="Select berth preference" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="No Preference">No Preference</SelectItem>
                        <SelectItem value="Lower">Lower</SelectItem>
                        <SelectItem value="Middle">Middle</SelectItem>
                        <SelectItem value="Upper">Upper</SelectItem>
                        <SelectItem value="Side Lower">Side Lower</SelectItem>
                        <SelectItem value="Side Upper">Side Upper</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="idType">ID Type</Label>
                      <Select
                        value={formData.idType}
                        onValueChange={(value) => handleSelectChange("idType", value)}
                      >
                        <SelectTrigger id="idType">
                          <SelectValue placeholder="Select ID Type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Aadhaar">Aadhaar</SelectItem>
                          <SelectItem value="Passport">Passport</SelectItem>
                          <SelectItem value="Driving License">Driving License</SelectItem>
                          <SelectItem value="PAN Card">PAN Card</SelectItem>
                          <SelectItem value="Voter ID">Voter ID</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="idNumber">ID Number</Label>
                      <Input
                        id="idNumber"
                        name="idNumber"
                        value={formData.idNumber}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="isDefault"
                      name="isDefault"
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      checked={formData.isDefault}
                      onChange={handleInputChange}
                    />
                    <Label
                      htmlFor="isDefault"
                      className="text-sm font-medium text-muted-foreground"
                    >
                      Set as default passenger
                    </Label>
                  </div>
                </div>

                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      resetForm();
                      setIsAddingPassenger(false);
                    }}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">
                    {editingPassenger ? "Save Changes" : "Add Passenger"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>

        <CardContent>
          <div className="space-y-4">
            {passengers.length > 0 ? (
              passengers.map((passenger) => (
                <Card key={passenger.id} className="bg-muted/30">
                  <CardContent className="p-4">
                    <div className="flex flex-wrap items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                          <User className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">{passenger.name}</h3>
                            {passenger.isDefault && (
                              <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs text-green-800">
                                Default
                              </span>
                            )}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {passenger.age} years • {passenger.gender} • {passenger.berth} Berth
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 gap-1"
                          onClick={() => handleEditPassenger(passenger)}
                        >
                          <Edit className="h-3.5 w-3.5" />
                          Edit
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          className="h-8 gap-1"
                          onClick={() => handleDeletePassenger(passenger.id)}
                        >
                          <Trash className="h-3.5 w-3.5" />
                          Delete
                        </Button>
                      </div>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-x-8 gap-y-2 text-sm md:grid-cols-3">
                      <div>
                        <span className="text-muted-foreground">ID Type:</span>{" "}
                        {passenger.idType}
                      </div>
                      <div>
                        <span className="text-muted-foreground">ID Number:</span>{" "}
                        {passenger.idNumber}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center rounded-lg border border-dashed py-12">
                <div className="rounded-full bg-muted p-3">
                  <User className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-lg font-medium">No saved passengers</h3>
                <p className="mt-2 text-center text-sm text-muted-foreground">
                  Add passengers to save their details for future bookings
                </p>
                <Button
                  className="mt-4 gap-2"
                  onClick={() => setIsAddingPassenger(true)}
                >
                  <Plus className="h-4 w-4" />
                  Add Passenger
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
