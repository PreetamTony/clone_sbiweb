"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CalendarIcon,
  ChevronRightIcon,
  DownloadIcon,
  FilterIcon,
  PrinterIcon,
  SearchIcon,
  TrainIcon,
} from "lucide-react";

// Mock booking history data
const mockBookings = [
  {
    id: "PNR4567812345",
    trainName: "Rajdhani Express",
    trainNumber: "12301",
    from: "New Delhi",
    to: "Howrah Jn",
    journeyDate: "2025-03-15",
    bookingDate: "2025-01-10",
    status: "Completed",
    passengers: 2,
    amount: "₹3,750",
    class: "3A",
  },
  {
    id: "PNR4567867890",
    trainName: "Shatabdi Express",
    trainNumber: "12005",
    from: "New Delhi",
    to: "Amritsar",
    journeyDate: "2025-04-05",
    bookingDate: "2025-02-20",
    status: "Upcoming",
    passengers: 1,
    amount: "₹1,450",
    class: "CC",
  },
  {
    id: "PNR4567854321",
    trainName: "Duronto Express",
    trainNumber: "12259",
    from: "Sealdah",
    to: "New Delhi",
    journeyDate: "2025-02-10",
    bookingDate: "2025-01-05",
    status: "Completed",
    passengers: 3,
    amount: "₹4,850",
    class: "2A",
  },
  {
    id: "PNR4567898765",
    trainName: "Garib Rath",
    trainNumber: "12203",
    from: "Kanpur",
    to: "Delhi",
    journeyDate: "2025-04-20",
    bookingDate: "2025-03-01",
    status: "Upcoming",
    passengers: 2,
    amount: "₹2,100",
    class: "3A",
  },
  {
    id: "PNR4567832109",
    trainName: "Poorva Express",
    trainNumber: "12303",
    from: "Howrah",
    to: "New Delhi",
    journeyDate: "2025-01-15",
    bookingDate: "2024-12-10",
    status: "Completed",
    passengers: 1,
    amount: "₹1,780",
    class: "SL",
  },
];

export function BookingHistory() {
  const [filteredBookings, setFilteredBookings] = useState(mockBookings);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Filter bookings based on search term and status
  const filterBookings = () => {
    let filtered = [...mockBookings];

    if (searchTerm) {
      filtered = filtered.filter(
        (booking) =>
          booking.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
          booking.trainName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          booking.trainNumber.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter((booking) => booking.status === statusFilter);
    }

    setFilteredBookings(filtered);
  };

  // Get status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "bg-green-100 text-green-800 hover:bg-green-100";
      case "Upcoming":
        return "bg-blue-100 text-blue-800 hover:bg-blue-100";
      case "Cancelled":
        return "bg-red-100 text-red-800 hover:bg-red-100";
      default:
        return "bg-gray-100 text-gray-800 hover:bg-gray-100";
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Booking History</CardTitle>
        </CardHeader>

        <CardContent>
          <div className="mb-6 grid gap-4 sm:grid-cols-3">
            <div className="sm:col-span-2">
              <div className="relative">
                <SearchIcon className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search PNR, Train Number or Name..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    filterBookings();
                  }}
                />
              </div>
            </div>

            <div>
              <Select
                value={statusFilter}
                onValueChange={(value) => {
                  setStatusFilter(value);
                  filterBookings();
                }}
              >
                <SelectTrigger>
                  <FilterIcon className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Bookings</SelectItem>
                  <SelectItem value="Upcoming">Upcoming</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                  <SelectItem value="Cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-4">
            {filteredBookings.length > 0 ? (
              filteredBookings.map((booking) => (
                <Card key={booking.id} className="overflow-hidden">
                  <div className="flex flex-col border-b p-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="mb-2 sm:mb-0">
                      <div className="flex items-center gap-2">
                        <TrainIcon className="h-5 w-5 text-primary" />
                        <span className="font-medium">{booking.trainName}</span>
                        <span className="text-sm text-muted-foreground">({booking.trainNumber})</span>
                      </div>
                      <div className="mt-1 text-sm text-muted-foreground">
                        {booking.from} to {booking.to} • {booking.class} • {new Date(booking.journeyDate).toLocaleDateString('en-US', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric'
                        })}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge className={getStatusColor(booking.status)}>
                        {booking.status}
                      </Badge>

                      <Button variant="outline" size="sm" className="h-8">
                        <ChevronRightIcon className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 p-4 sm:grid-cols-4">
                    <div>
                      <div className="text-sm text-muted-foreground">PNR Number</div>
                      <div className="font-medium">{booking.id}</div>
                    </div>

                    <div>
                      <div className="text-sm text-muted-foreground">Booking Date</div>
                      <div className="font-medium">{new Date(booking.bookingDate).toLocaleDateString('en-US', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric'
                      })}</div>
                    </div>

                    <div>
                      <div className="text-sm text-muted-foreground">Passengers</div>
                      <div className="font-medium">{booking.passengers}</div>
                    </div>

                    <div>
                      <div className="text-sm text-muted-foreground">Amount</div>
                      <div className="font-medium">{booking.amount}</div>
                    </div>
                  </div>

                  {booking.status === "Upcoming" && (
                    <div className="flex justify-end gap-2 border-t bg-muted/30 px-4 py-2">
                      <Button size="sm" variant="outline" className="gap-1 h-8">
                        <PrinterIcon className="h-3.5 w-3.5" />
                        Print Ticket
                      </Button>
                      <Button size="sm" className="gap-1 h-8">
                        <DownloadIcon className="h-3.5 w-3.5" />
                        E-Ticket
                      </Button>
                    </div>
                  )}
                </Card>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center rounded-lg border border-dashed py-12">
                <div className="rounded-full bg-muted p-3">
                  <CalendarIcon className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-lg font-medium">No bookings found</h3>
                <p className="mt-2 text-center text-sm text-muted-foreground">
                  {searchTerm || statusFilter !== "all"
                    ? "Try adjusting your search or filter criteria"
                    : "You haven't made any bookings yet"}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
