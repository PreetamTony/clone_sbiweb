"use client";

import { useState } from "react";
import Image from "next/image";
import { Calendar, ChevronRight, MapPin, Search, Train, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CheckCircle } from "lucide-react";
import { useLanguage } from "@/components/language/language-provider";

const travelClasses = [
  { id: "all", name: "All Classes" },
  { id: "1A", name: "First AC" },
  { id: "2A", name: "Second AC" },
  { id: "3A", name: "Third AC" },
  { id: "SL", name: "Sleeper" },
  { id: "2S", name: "Second Sitting" },
];

export function HeroSection() {
  const [fromStation, setFromStation] = useState("");
  const [toStation, setToStation] = useState("");
  const [date, setDate] = useState("");
  const [travelClass, setTravelClass] = useState("all");
  const { t } = useLanguage();

  return (
    <section className="relative bg-gradient-to-b from-blue-50 to-white">
      <div className="container py-10 md:py-16">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2 lg:gap-20">
          <div className="flex flex-col justify-center">
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
              <span className="text-primary">{t("home.title")}</span>
            </h1>
            <p className="mt-4 text-lg text-muted-foreground">
              {t("home.subtitle")}
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <div className="flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm">
                <CheckCircle className="h-4 w-4 text-primary" /> {t("home.feature.fastBooking")}
              </div>
              <div className="flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm">
                <CheckCircle className="h-4 w-4 text-primary" /> {t("home.feature.noHiddenFees")}
              </div>
              <div className="flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm">
                <CheckCircle className="h-4 w-4 text-primary" /> {t("home.feature.securePayments")}
              </div>
            </div>
          </div>

          <div>
            <Card className="overflow-hidden border-none shadow-lg">
              <Tabs defaultValue="book" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="book">{t("home.form.bookTicket")}</TabsTrigger>
                  <TabsTrigger value="pnr">{t("home.form.pnrStatus")}</TabsTrigger>
                </TabsList>

                <TabsContent value="book" className="mt-0">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="from">{t("home.form.from")}</Label>
                          <div className="relative">
                            <MapPin className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                            <Input
                              id="from"
                              placeholder={t("home.form.enterCity")}
                              className="pl-10"
                              value={fromStation}
                              onChange={(e) => setFromStation(e.target.value)}
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="to">{t("home.form.to")}</Label>
                          <div className="relative">
                            <MapPin className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                            <Input
                              id="to"
                              placeholder={t("home.form.enterCity")}
                              className="pl-10"
                              value={toStation}
                              onChange={(e) => setToStation(e.target.value)}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="date">{t("home.form.date")}</Label>
                          <div className="relative">
                            <Calendar className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                            <Input
                              id="date"
                              type="date"
                              className="pl-10"
                              value={date}
                              onChange={(e) => setDate(e.target.value)}
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="class">{t("home.form.travelClass")}</Label>
                          <div className="relative">
                            <Users className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                            <Select
                              value={travelClass}
                              onValueChange={setTravelClass}
                            >
                              <SelectTrigger className="pl-10" id="class">
                                <SelectValue placeholder={t("home.form.selectClass")} />
                              </SelectTrigger>
                              <SelectContent>
                                {travelClasses.map((travelClass) => (
                                  <SelectItem key={travelClass.id} value={travelClass.id}>
                                    {travelClass.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <div className="flex h-5 items-center space-x-2">
                            <input
                              type="checkbox"
                              id="flexibleDates"
                              className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                            />
                            <label
                              htmlFor="flexibleDates"
                              className="text-sm font-medium text-muted-foreground"
                            >
                              {t("home.form.flexibleDates")}
                            </label>
                          </div>

                          <div className="flex h-5 items-center space-x-2">
                            <input
                              type="checkbox"
                              id="divyangConcession"
                              className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                            />
                            <label
                              htmlFor="divyangConcession"
                              className="text-sm font-medium text-muted-foreground"
                            >
                              {t("home.form.disabilityConcession")}
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>

                  <CardFooter className="bg-muted/50 p-6">
                    <Button className="w-full gap-2">
                      <Search className="h-4 w-4" />
                      {t("home.form.findTrains")}
                    </Button>
                  </CardFooter>
                </TabsContent>

                <TabsContent value="pnr" className="mt-0">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="pnr">{t("home.form.pnrNumber")}</Label>
                        <div className="relative">
                          <Train className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input
                            id="pnr"
                            placeholder={t("home.form.enterPNR")}
                            className="pl-10"
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>

                  <CardFooter className="bg-muted/50 p-6">
                    <Button className="w-full gap-2">
                      <Search className="h-4 w-4" />
                      {t("home.form.checkPNRStatus")}
                    </Button>
                  </CardFooter>
                </TabsContent>
              </Tabs>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
