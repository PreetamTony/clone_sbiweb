import Image from "next/image";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Info, Clock, AlertTriangle, Ban, Calendar, FileCheck } from "lucide-react";

interface TipProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const travelTips: TipProps[] = [
  {
    icon: <Calendar className="h-7 w-7 text-primary" />,
    title: "Book in Advance",
    description: "Reserve your tickets at least 60 days in advance for better seat availability and lower fares.",
  },
  {
    icon: <Clock className="h-7 w-7 text-primary" />,
    title: "Check Timings",
    description: "Always check train timings before departing for the station, as schedules may occasionally change.",
  },
  {
    icon: <AlertTriangle className="h-7 w-7 text-primary" />,
    title: "Verify PNR Status",
    description: "Check your PNR status before traveling to ensure your ticket is confirmed or has a good waitlist position.",
  },
  {
    icon: <FileCheck className="h-7 w-7 text-primary" />,
    title: "Keep Documents Handy",
    description: "Always carry your ID proof and e-ticket or physical ticket when traveling by train.",
  },
  {
    icon: <Ban className="h-7 w-7 text-primary" />,
    title: "Avoid Touts",
    description: "Do not approach unauthorized agents or touts. Book tickets through official IRCTC channels only.",
  },
  {
    icon: <Info className="h-7 w-7 text-primary" />,
    title: "Know Your Rights",
    description: "Familiarize yourself with passenger rights, including refund rules and complaint procedures.",
  },
];

export function TravelTips() {
  return (
    <section className="bg-white py-16">
      <div className="container">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Essential Travel Tips</h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Make your train journey smoother with these important travel tips and information.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {travelTips.map((tip, index) => (
            <Card key={index} className="border-none bg-muted/30 shadow-none">
              <CardContent className="flex flex-col p-6">
                <div className="mb-4">{tip.icon}</div>
                <h3 className="mb-2 text-xl font-medium">{tip.title}</h3>
                <p className="text-muted-foreground">{tip.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 flex justify-center">
          <Link href="/help/travel-tips">
            <Button variant="outline" className="gap-2">
              More Travel Tips
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
