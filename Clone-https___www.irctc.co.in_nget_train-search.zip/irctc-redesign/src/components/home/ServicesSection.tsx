import Image from "next/image";
import Link from "next/link";
import {
  Train, Plane, Building, Bus, Ship, MapPin,
  UtensilsCrossed, Package, Landmark
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface ServiceProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  href: string;
}

const services: ServiceProps[] = [
  {
    icon: <Train className="h-10 w-10 text-primary" />,
    title: "Train Tickets",
    description: "Book train tickets for any route across India with ease and convenience.",
    href: "/trains/booking",
  },
  {
    icon: <Plane className="h-10 w-10 text-primary" />,
    title: "Flight Bookings",
    description: "Find the best deals on domestic and international flights.",
    href: "/flights",
  },
  {
    icon: <Building className="h-10 w-10 text-primary" />,
    title: "Hotel Stays",
    description: "Book comfortable accommodations for your travel at the best prices.",
    href: "/hotels",
  },
  {
    icon: <Bus className="h-10 w-10 text-primary" />,
    title: "Bus Services",
    description: "Convenient bus bookings for intercity travel across the country.",
    href: "/bus",
  },
  {
    icon: <Package className="h-10 w-10 text-primary" />,
    title: "Holiday Packages",
    description: "All-inclusive travel packages for a hassle-free vacation experience.",
    href: "/holidays",
  },
  {
    icon: <UtensilsCrossed className="h-10 w-10 text-primary" />,
    title: "E-Catering",
    description: "Order delicious food delivered directly to your train seat.",
    href: "/services/catering",
  },
  {
    icon: <Ship className="h-10 w-10 text-primary" />,
    title: "Tour Packages",
    description: "Explore tourist trains and specialized tour packages.",
    href: "/services/tour-packages",
  },
  {
    icon: <Landmark className="h-10 w-10 text-primary" />,
    title: "Retiring Rooms",
    description: "Book retiring rooms at railway stations for short stays.",
    href: "/services/retiring-rooms",
  },
];

export function ServicesSection() {
  return (
    <section className="bg-white py-16">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">All Your Travel Needs in One Place</h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Discover our comprehensive range of travel services designed to make your journey seamless and enjoyable.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((service, index) => (
            <Link key={index} href={service.href} className="group">
              <Card className="h-full transition-all duration-200 hover:border-primary hover:shadow-md">
                <CardContent className="flex h-full flex-col p-6">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 group-hover:bg-primary/20">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-medium">{service.title}</h3>
                  <p className="mt-2 flex-1 text-sm text-muted-foreground">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
