import Image from "next/image";
import Link from "next/link";
import { MapPin } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface DestinationProps {
  title: string;
  location: string;
  image: string;
  href: string;
}

const destinations: DestinationProps[] = [
  {
    title: "Taj Mahal",
    location: "Agra, Uttar Pradesh",
    image: "https://ext.same-assets.com/1849439527/taj-mahal.jpg",
    href: "/destinations/taj-mahal",
  },
  {
    title: "Golden Temple",
    location: "Amritsar, Punjab",
    image: "https://ext.same-assets.com/1849439527/golden-temple.jpg",
    href: "/destinations/golden-temple",
  },
  {
    title: "Varanasi Ghats",
    location: "Varanasi, Uttar Pradesh",
    image: "https://ext.same-assets.com/1849439527/varanasi.jpg",
    href: "/destinations/varanasi",
  },
  {
    title: "Kerala Backwaters",
    location: "Alleppey, Kerala",
    image: "https://ext.same-assets.com/1849439527/kerala-backwaters.jpg",
    href: "/destinations/kerala-backwaters",
  },
  {
    title: "Jaipur",
    location: "Rajasthan",
    image: "https://ext.same-assets.com/1849439527/jaipur.jpg",
    href: "/destinations/jaipur",
  },
  {
    title: "Darjeeling",
    location: "West Bengal",
    image: "https://ext.same-assets.com/1849439527/darjeeling.jpg",
    href: "/destinations/darjeeling",
  },
];

export function PopularDestinations() {
  return (
    <section className="bg-muted/30 py-16">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Explore Popular Destinations</h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Discover some of India's most beloved destinations and plan your next adventure.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {destinations.map((destination, index) => (
            <Link key={index} href={destination.href} className="group">
              <Card className="h-full overflow-hidden transition-all duration-200 hover:border-primary hover:shadow-md">
                <div className="relative h-60 w-full overflow-hidden">
                  <Image
                    src={destination.image}
                    alt={destination.title}
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    fill
                  />
                </div>
                <CardContent className="p-5">
                  <h3 className="text-xl font-medium">{destination.title}</h3>
                  <div className="mt-1 flex items-center text-sm text-muted-foreground">
                    <MapPin className="mr-1 h-4 w-4" />
                    {destination.location}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
