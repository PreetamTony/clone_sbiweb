"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

interface SeatMapProps {
  coachType: string;
  onSeatSelect: (coach: string, seatNumber: string, berthType: string) => void;
  passengerBerthPreference: string;
}

interface Seat {
  number: string;
  berthType: string;
  status: "available" | "booked" | "ladies" | "selected";
}

export function SeatMap({ coachType, onSeatSelect, passengerBerthPreference }: SeatMapProps) {
  const [coach, setCoach] = useState("B2");
  const [seats, setSeats] = useState<Seat[]>([]);
  const [selectedSeat, setSelectedSeat] = useState<string | null>(null);

  // Generate seats based on coach type
  useEffect(() => {
    if (coachType === "3A") {
      generateThreeTierACSeats();
    }
  }, [coachType]);

  // Generate 3A coach seats
  const generateThreeTierACSeats = () => {
    const newSeats: Seat[] = [];
    const totalBays = 18; // 3A coach typically has 18 bays

    for (let bay = 1; bay <= totalBays; bay++) {
      // Each bay in 3A has 6 berths: Lower, Middle, Upper on both sides
      const bayStartSeat = (bay - 1) * 8 + 1;

      // Side 1 (Left side)
      newSeats.push({
        number: bayStartSeat.toString(),
        berthType: "Lower",
        status: getRandomSeatStatus(),
      });

      newSeats.push({
        number: (bayStartSeat + 1).toString(),
        berthType: "Middle",
        status: getRandomSeatStatus(),
      });

      newSeats.push({
        number: (bayStartSeat + 2).toString(),
        berthType: "Upper",
        status: getRandomSeatStatus(),
      });

      // Side 2 (Right side)
      newSeats.push({
        number: (bayStartSeat + 3).toString(),
        berthType: "Lower",
        status: getRandomSeatStatus(),
      });

      newSeats.push({
        number: (bayStartSeat + 4).toString(),
        berthType: "Middle",
        status: getRandomSeatStatus(),
      });

      newSeats.push({
        number: (bayStartSeat + 5).toString(),
        berthType: "Upper",
        status: getRandomSeatStatus(),
      });

      // Side berths (at the end of each set of 3 bays)
      if (bay % 3 === 0) {
        newSeats.push({
          number: (bayStartSeat + 6).toString(),
          berthType: "Side Lower",
          status: getRandomSeatStatus(),
        });

        newSeats.push({
          number: (bayStartSeat + 7).toString(),
          berthType: "Side Upper",
          status: getRandomSeatStatus(),
        });
      }
    }

    // Override some seats to match passenger preference if possible
    if (passengerBerthPreference) {
      const preferredSeats = newSeats.filter(
        (seat) =>
          seat.status === "available" &&
          seat.berthType.toLowerCase().includes(passengerBerthPreference.toLowerCase())
      );

      if (preferredSeats.length > 0) {
        // Highlight at least one preferred seat as available
        const randomIndex = Math.floor(Math.random() * preferredSeats.length);
        preferredSeats[randomIndex].status = "available";

        // Make some nearby seats available too for family booking
        const seatIndex = newSeats.findIndex(s => s.number === preferredSeats[randomIndex].number);
        if (seatIndex !== -1 && seatIndex > 0 && seatIndex < newSeats.length - 1) {
          newSeats[seatIndex - 1].status = "available";
          if (seatIndex + 1 < newSeats.length) {
            newSeats[seatIndex + 1].status = "available";
          }
        }
      }
    }

    setSeats(newSeats);
  };

  // Generate random seat status for demo
  const getRandomSeatStatus = (): "available" | "booked" | "ladies" => {
    const rand = Math.random();
    if (rand < 0.6) return "available"; // 60% seats available
    if (rand < 0.9) return "booked";    // 30% seats booked
    return "ladies";                     // 10% ladies seats
  };

  // Handle seat selection
  const handleSeatClick = (seat: Seat) => {
    if (seat.status !== "available") return;

    // Update selected seat
    setSelectedSeat(seat.number);

    // Update seat status
    setSeats(
      seats.map((s) => ({
        ...s,
        status: s.number === seat.number ? "selected" :
                s.status === "selected" ? "available" : s.status,
      }))
    );

    // Call the callback function
    onSeatSelect(coach, seat.number, seat.berthType);
  };

  // Get color class for seat based on status
  const getSeatColorClass = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 border-green-200 hover:bg-green-200";
      case "booked":
        return "bg-red-100 border-red-200 text-red-700 cursor-not-allowed";
      case "ladies":
        return "bg-yellow-100 border-yellow-200 text-yellow-700 cursor-not-allowed";
      case "selected":
        return "bg-blue-100 border-2 border-primary text-primary";
      default:
        return "bg-gray-100 border-gray-200";
    }
  };

  // Render seat with berth type
  const renderSeat = (seat: Seat) => {
    return (
      <div
        key={seat.number}
        className={`flex h-16 w-24 cursor-pointer flex-col items-center justify-center rounded-md border p-1 text-center transition-colors ${getSeatColorClass(
          seat.status
        )}`}
        onClick={() => handleSeatClick(seat)}
      >
        <div className="text-sm font-medium">{seat.number}</div>
        <div className="text-xs">{seat.berthType}</div>
        {seat.status === "selected" && <CheckCircle className="h-4 w-4 text-primary" />}
      </div>
    );
  };

  // Organize seats into bays for better display
  const renderCoach = () => {
    const bays = [];
    let currentBay = [];
    let sideSeats: Seat[] = [];

    for (let i = 0; i < seats.length; i++) {
      const seat = seats[i];

      if (seat.berthType.includes("Side")) {
        sideSeats.push(seat);

        // If we have 2 side seats, add them as a separate bay
        if (sideSeats.length === 2) {
          bays.push(
            <div key={`side-${i}`} className="flex flex-col items-center space-y-2">
              {sideSeats.map(renderSeat)}
            </div>
          );
          sideSeats = [];
        }
      } else {
        currentBay.push(seat);

        // If we have 6 regular seats, add them as a bay (3 on each side)
        if (currentBay.length === 6) {
          bays.push(
            <div key={`bay-${i}`} className="flex flex-col space-y-2">
              <div className="flex justify-between space-x-2">
                {currentBay.slice(0, 3).map(renderSeat)}
              </div>
              <div className="flex justify-between space-x-2">
                {currentBay.slice(3, 6).map(renderSeat)}
              </div>
            </div>
          );
          currentBay = [];
        }
      }
    }

    return (
      <div className="flex flex-wrap gap-4">
        {bays}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2 overflow-x-auto pb-2">
        {["B1", "B2", "B3", "B4", "B5"].map((coachName) => (
          <Button
            key={coachName}
            variant={coach === coachName ? "default" : "outline"}
            className="h-8"
            onClick={() => setCoach(coachName)}
          >
            Coach {coachName}
          </Button>
        ))}
      </div>

      <div className="relative min-h-[400px] rounded-lg border bg-white p-4">
        <div className="absolute inset-x-0 top-0 h-2 bg-primary"></div>
        <div className="absolute inset-y-0 left-0 w-2 bg-primary"></div>

        <div className="ml-4 mt-4">
          <div className="mb-4 text-center font-medium">
            Coach {coach} - {coachType === "3A" ? "AC Three Tier" : coachType}
          </div>

          <div className="my-4 overflow-x-auto pb-2">
            {renderCoach()}
          </div>
        </div>
      </div>
    </div>
  );
}
