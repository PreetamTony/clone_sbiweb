import { MainLayout } from "@/components/layout/MainLayout";
import { HeroSection } from "@/components/home/HeroSection";
import { ServicesSection } from "@/components/home/ServicesSection";
import { PopularDestinations } from "@/components/home/PopularDestinations";
import { TravelTips } from "@/components/home/TravelTips";

export default function Home() {
  return (
    <MainLayout>
      <HeroSection />
      <ServicesSection />
      <PopularDestinations />
      <TravelTips />
    </MainLayout>
  );
}
