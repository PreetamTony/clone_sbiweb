"use client";

import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProfileInfo } from "@/components/profile/profile-info";
import { BookingHistory } from "@/components/profile/booking-history";
import { SavedPassengers } from "@/components/profile/saved-passengers";
import { Settings } from "@/components/profile/settings";

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("profile");

  return (
    <MainLayout>
      <div className="container py-8">
        <h1 className="mb-8 text-3xl font-bold">My Account</h1>

        <Tabs defaultValue="profile" onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-8 w-full sm:w-auto">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="bookings">Booking History</TabsTrigger>
            <TabsTrigger value="passengers">Saved Passengers</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            <ProfileInfo />
          </TabsContent>

          <TabsContent value="bookings">
            <BookingHistory />
          </TabsContent>

          <TabsContent value="passengers">
            <SavedPassengers />
          </TabsContent>

          <TabsContent value="settings">
            <Settings />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
