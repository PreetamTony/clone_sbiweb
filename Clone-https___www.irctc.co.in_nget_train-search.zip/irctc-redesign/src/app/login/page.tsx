"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Eye, EyeOff, Lock, Mail, Smartphone } from "lucide-react";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();

    if (!username || !password) {
      alert("Please enter both username and password");
      return;
    }

    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      // In a real app, redirect to dashboard after login
      window.location.href = "/";
    }, 1500);
  };

  return (
    <MainLayout>
      <section className="py-12">
        <div className="container">
          <div className="mx-auto max-w-md">
            <Card className="border-none shadow-lg">
              <Tabs defaultValue="username" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="username">Username</TabsTrigger>
                  <TabsTrigger value="mobile">Mobile No</TabsTrigger>
                  <TabsTrigger value="otp">OTP</TabsTrigger>
                </TabsList>

                <CardHeader className="pb-4 pt-6">
                  <CardTitle className="text-center text-2xl">Login to IRCTC</CardTitle>
                  <CardDescription className="text-center">
                    Sign in to your account to book tickets and manage your travel
                  </CardDescription>
                </CardHeader>

                <TabsContent value="username">
                  <form onSubmit={handleLogin}>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="username">Username</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input
                            id="username"
                            placeholder="Enter username or email"
                            className="pl-10"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label htmlFor="password">Password</Label>
                          <Link
                            href="/forgot-password"
                            className="text-xs text-primary hover:underline"
                          >
                            Forgot password?
                          </Link>
                        </div>
                        <div className="relative">
                          <Lock className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input
                            id="password"
                            type={showPassword ? "text" : "password"}
                            placeholder="Enter your password"
                            className="pl-10 pr-10"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground"
                            tabIndex={-1}
                          >
                            {showPassword ? (
                              <EyeOff className="h-5 w-5" />
                            ) : (
                              <Eye className="h-5 w-5" />
                            )}
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="rememberMe"
                          className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                        />
                        <label
                          htmlFor="rememberMe"
                          className="text-sm font-medium text-muted-foreground"
                        >
                          Remember me on this device
                        </label>
                      </div>
                    </CardContent>

                    <CardFooter className="flex flex-col gap-4">
                      <Button
                        type="submit"
                        className="w-full"
                        disabled={isLoading}
                      >
                        {isLoading ? "Logging in..." : "Login"}
                      </Button>

                      <div className="text-center text-sm">
                        <span className="text-muted-foreground">Don't have an account? </span>
                        <Link href="/register" className="text-primary hover:underline">
                          Sign up
                        </Link>
                      </div>
                    </CardFooter>
                  </form>
                </TabsContent>

                <TabsContent value="mobile">
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="mobile">Mobile Number</Label>
                      <div className="relative">
                        <Smartphone className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                        <Input
                          id="mobile"
                          placeholder="Enter 10 digit mobile number"
                          className="pl-10"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password-mobile">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                        <Input
                          id="password-mobile"
                          type="password"
                          placeholder="Enter your password"
                          className="pl-10"
                        />
                      </div>
                      <div className="text-right">
                        <Link
                          href="/forgot-password"
                          className="text-xs text-primary hover:underline"
                        >
                          Forgot password?
                        </Link>
                      </div>
                    </div>
                  </CardContent>

                  <CardFooter className="flex flex-col gap-4">
                    <Button className="w-full">Login</Button>
                    <div className="text-center text-sm">
                      <span className="text-muted-foreground">Don't have an account? </span>
                      <Link href="/register" className="text-primary hover:underline">
                        Sign up
                      </Link>
                    </div>
                  </CardFooter>
                </TabsContent>

                <TabsContent value="otp">
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="mobile-otp">Mobile Number</Label>
                      <div className="relative">
                        <Smartphone className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                        <Input
                          id="mobile-otp"
                          placeholder="Enter 10 digit mobile number"
                          className="pl-10"
                        />
                      </div>
                    </div>

                    <Button className="w-full">Send OTP</Button>

                    <div className="flex items-center gap-2 rounded-lg bg-muted/50 p-3 text-sm">
                      <AlertCircle className="h-5 w-5 text-primary" />
                      <p>We'll send a one-time password to your registered mobile number</p>
                    </div>
                  </CardContent>
                </TabsContent>
              </Tabs>
            </Card>

            <div className="mt-8">
              <h3 className="mb-4 text-center text-sm font-medium text-muted-foreground">Login Assistance</h3>
              <div className="flex flex-wrap justify-center gap-4">
                <Button variant="outline" size="sm" asChild>
                  <a href="/help/login-issues">Login Issues</a>
                </Button>
                <Button variant="outline" size="sm" asChild>
                  <a href="/help/account-recovery">Account Recovery</a>
                </Button>
                <Button variant="outline" size="sm" asChild>
                  <a href="/help">Help Center</a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
