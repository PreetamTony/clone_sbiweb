"use client";

import { useState } from "react";
import Link from "next/link";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, Info, Train, User, Users, CreditCard, Loader2 } from "lucide-react";
import { SeatMap } from "@/components/trains/seat-map";

// Mock booking details
const bookingDetails = {
  train: {
    number: "12301",
    name: "Howrah - New Delhi Rajdhani Express",
    from: "New Delhi (NDLS)",
    to: "Howrah Jn (HWH)",
    departureDate: "29 Mar 2025",
    departureTime: "16:55",
    arrivalTime: "09:55 (+1)",
    duration: "17h 00m",
    class: "3A",
  },
  passengers: [
    {
      id: 1,
      name: "Rahul Sharma",
      age: 32,
      gender: "Male",
      berthPreference: "Lower",
      selectedSeat: "",
      idType: "Aadhaar",
      idNumber: "XXXX-XXXX-1234",
    },
    {
      id: 2,
      name: "Priya Sharma",
      age: 29,
      gender: "Female",
      berthPreference: "Upper",
      selectedSeat: "",
      idType: "Aadhaar",
      idNumber: "XXXX-XXXX-5678",
    },
  ],
  totalFare: "₹ 3,780",
};

export default function SeatSelectionPage() {
  const [selectedPassenger, setSelectedPassenger] = useState(bookingDetails.passengers[0].id);
  const [isProcessing, setIsProcessing] = useState(false);

  // Update the selected seat for the current passenger
  const handleSeatSelection = (coach: string, seatNumber: string, berthType: string) => {
    const passengerIndex = bookingDetails.passengers.findIndex((p) => p.id === selectedPassenger);
    if (passengerIndex !== -1) {
      bookingDetails.passengers[passengerIndex].selectedSeat = `${coach}-${seatNumber} (${berthType})`;
    }
  };

  // Check if all passengers have selected seats
  const allPassengersHaveSeats = () => {
    return bookingDetails.passengers.every((passenger) => passenger.selectedSeat);
  };

  // Proceed to payment
  const handleProceedToPayment = () => {
    if (!allPassengersHaveSeats()) {
      alert("Please select seats for all passengers.");
      return;
    }

    setIsProcessing(true);

    // Simulate API call delay
    setTimeout(() => {
      setIsProcessing(false);
      // Redirect to payment page (would be done with router in real app)
      window.location.href = "/trains/booking/payment";
    }, 1500);
  };

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold md:text-3xl">Seat Selection</h1>
            <p className="text-muted-foreground">Choose your preferred seats for your journey</p>
          </div>

          <div className="mt-2 flex items-center gap-1 rounded-full bg-blue-50 px-4 py-1 text-sm text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 sm:mt-0">
            <span className="font-medium">Step 2 of 3</span>
            <ChevronRight className="h-4 w-4" />
            <span>Payment</span>
          </div>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle>Select Passenger</CardTitle>
                  <Badge
                    variant={allPassengersHaveSeats() ? "default" : "outline"}
                    className={allPassengersHaveSeats() ? "bg-green-100 text-green-800 hover:bg-green-100" : ""}
                  >
                    {allPassengersHaveSeats() ? "All seats selected" : "Select seats for all passengers"}
                  </Badge>
                </div>
                <CardDescription>
                  Click on a passenger to select seats for them
                </CardDescription>
              </CardHeader>

              <CardContent>
                <div className="space-y-2">
                  {bookingDetails.passengers.map((passenger) => (
                    <div
                      key={passenger.id}
                      onClick={() => setSelectedPassenger(passenger.id)}
                      className={`cursor-pointer rounded-lg p-3 transition-colors ${
                        selectedPassenger === passenger.id
                          ? "bg-primary/10 hover:bg-primary/15"
                          : "hover:bg-muted"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`flex h-10 w-10 items-center justify-center rounded-full ${
                            selectedPassenger === passenger.id
                              ? "bg-primary/20 text-primary"
                              : "bg-muted text-muted-foreground"
                          }`}>
                            <User className="h-5 w-5" />
                          </div>
                          <div>
                            <div className="font-medium">{passenger.name}</div>
                            <div className="text-sm text-muted-foreground">
                              {passenger.age} yrs • {passenger.gender} • Berth Preference: {passenger.berthPreference}
                            </div>
                          </div>
                        </div>

                        <div>
                          {passenger.selectedSeat ? (
                            <Badge
                              variant="outline"
                              className="bg-green-100 text-green-800 hover:bg-green-100"
                            >
                              {passenger.selectedSeat}
                            </Badge>
                          ) : (
                            <Badge variant="outline">No seat selected</Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Coach B2 - 3A (AC Three Tier)</CardTitle>
                  <CardDescription>
                    Select seats for {bookingDetails.passengers.find((p) => p.id === selectedPassenger)?.name}
                  </CardDescription>
                </CardHeader>

                <CardContent>
                  <div className="mb-4 flex items-center justify-between rounded-lg bg-muted/30 p-3">
                    <div className="flex items-center gap-2">
                      <Info className="h-5 w-5 text-primary" />
                      <span className="text-sm">
                        Click on an available seat to select it. You can select adjacent seats for a better journey experience.
                      </span>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <SeatMap
                      coachType="3A"
                      onSeatSelect={handleSeatSelection}
                      passengerBerthPreference={
                        bookingDetails.passengers.find((p) => p.id === selectedPassenger)?.berthPreference || ""
                      }
                    />
                  </div>

                  <div className="mt-4 flex flex-wrap items-center gap-4">
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 rounded-sm border bg-green-100"></div>
                      <span className="text-sm">Available</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 rounded-sm border bg-red-100"></div>
                      <span className="text-sm">Booked</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 rounded-sm border bg-yellow-100"></div>
                      <span className="text-sm">Ladies</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 rounded-sm border-2 border-primary bg-blue-100"></div>
                      <span className="text-sm">Selected</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="lg:col-span-1">
            <Card className="sticky top-20">
              <CardHeader className="border-b pb-4">
                <CardTitle>Booking Summary</CardTitle>
              </CardHeader>

              <CardContent className="pt-4">
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <Train className="h-5 w-5 text-primary" />
                      <div className="font-medium">{bookingDetails.train.name}</div>
                    </div>
                    <div className="mt-1 text-sm text-muted-foreground">
                      {bookingDetails.train.number} • {bookingDetails.train.class}
                    </div>
                  </div>

                  <div className="flex justify-between pt-1 text-sm">
                    <div>
                      <div className="font-medium">{bookingDetails.train.departureTime}</div>
                      <div className="text-muted-foreground">{bookingDetails.train.from}</div>
                    </div>
                    <div className="text-center text-muted-foreground">
                      <div className="text-xs">{bookingDetails.train.duration}</div>
                      <div className="relative mt-1 h-0.5 w-16 bg-muted">
                        <div className="absolute -bottom-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rounded-full bg-primary"></div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{bookingDetails.train.arrivalTime}</div>
                      <div className="text-muted-foreground">{bookingDetails.train.to}</div>
                    </div>
                  </div>

                  <div className="rounded-lg border p-3">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium">Travel Date</div>
                      <div>{bookingDetails.train.departureDate}</div>
                    </div>
                  </div>

                  <div className="rounded-lg border p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Passengers</span>
                      </div>
                      <div>{bookingDetails.passengers.length}</div>
                    </div>

                    <div className="mt-2 space-y-2 pt-2 text-sm">
                      {bookingDetails.passengers.map((passenger, index) => (
                        <div key={passenger.id} className="flex items-center justify-between">
                          <div className="text-muted-foreground">
                            {index + 1}. {passenger.name}
                          </div>
                          {passenger.selectedSeat && (
                            <div className="font-medium">{passenger.selectedSeat}</div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-lg bg-muted/30 p-3">
                    <div className="flex items-center justify-between text-sm">
                      <div className="text-muted-foreground">Base Fare</div>
                      <div>₹ 3,380</div>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="text-muted-foreground">GST</div>
                      <div>₹ 169</div>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="text-muted-foreground">Convenience Fee</div>
                      <div>₹ 231</div>
                    </div>
                    <div className="mt-2 flex items-center justify-between border-t pt-2 font-medium">
                      <div>Total Amount</div>
                      <div className="text-lg">{bookingDetails.totalFare}</div>
                    </div>
                  </div>
                </div>
              </CardContent>

              <CardFooter className="flex flex-col gap-3 border-t pt-4">
                <Button
                  className="w-full gap-2"
                  onClick={handleProceedToPayment}
                  disabled={!allPassengersHaveSeats() || isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <CreditCard className="h-4 w-4" />
                      Proceed to Payment
                    </>
                  )}
                </Button>

                <Button
                  variant="outline"
                  className="w-full"
                  asChild
                >
                  <Link href="/trains/booking">Back to Train Selection</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
