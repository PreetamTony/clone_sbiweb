"use client";

import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Calendar,
  CheckCircle2,
  Clock,
  Info,
  MapPin,
  Search,
  Sparkles,
  Train,
  User,
  Users,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const travelClasses = [
  { id: "all", name: "All Classes" },
  { id: "1A", name: "First AC" },
  { id: "2A", name: "Second AC" },
  { id: "3A", name: "Third AC" },
  { id: "SL", name: "Sleeper" },
  { id: "2S", name: "Second Sitting" },
  { id: "CC", name: "AC Chair Car" },
  { id: "EC", name: "Exec. Chair Car" },
];

const quotas = [
  { id: "GN", name: "General Quota" },
  { id: "LD", name: "Ladies Quota" },
  { id: "TQ", name: "Tatkal Quota" },
  { id: "PT", name: "Premium Tatkal" },
  { id: "SS", name: "Senior Citizen" },
  { id: "DP", name: "Divyangjan" },
];

export default function TrainBookingPage() {
  const [fromStation, setFromStation] = useState("");
  const [toStation, setToStation] = useState("");
  const [date, setDate] = useState("");
  const [travelClass, setTravelClass] = useState("all");
  const [quota, setQuota] = useState("GN");

  return (
    <MainLayout>
      <section className="bg-gradient-to-b from-blue-50 to-white py-8 md:py-12">
        <div className="container">
          <div className="mx-auto max-w-3xl">
            <h1 className="text-center text-3xl font-bold tracking-tight md:text-4xl">Book Train Tickets</h1>
            <p className="mt-3 text-center text-muted-foreground">
              Search for trains, check availability, and book tickets in a few simple steps
            </p>

            <Card className="mt-8 overflow-hidden">
              <Tabs defaultValue="regular" className="w-full">
                <TabsList className="w-full grid grid-cols-3">
                  <TabsTrigger value="regular">Regular</TabsTrigger>
                  <TabsTrigger value="tatkal">Tatkal</TabsTrigger>
                  <TabsTrigger value="connecting">Connecting Journey</TabsTrigger>
                </TabsList>

                <CardContent className="p-6">
                  <div className="space-y-5">
                    <div className="flex flex-col gap-5 sm:flex-row">
                      <div className="flex-1 space-y-2">
                        <Label htmlFor="from">From Station</Label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input
                            id="from"
                            placeholder="Enter city or station"
                            className="pl-10"
                            value={fromStation}
                            onChange={(e) => setFromStation(e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="flex-1 space-y-2">
                        <Label htmlFor="to">To Station</Label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input
                            id="to"
                            placeholder="Enter city or station"
                            className="pl-10"
                            value={toStation}
                            onChange={(e) => setToStation(e.target.value)}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-5 sm:flex-row">
                      <div className="flex-1 space-y-2">
                        <Label htmlFor="date">Journey Date</Label>
                        <div className="relative">
                          <Calendar className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input
                            id="date"
                            type="date"
                            className="pl-10"
                            value={date}
                            onChange={(e) => setDate(e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="flex-1 space-y-2">
                        <Label htmlFor="class">Travel Class</Label>
                        <div className="relative">
                          <Users className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Select
                            value={travelClass}
                            onValueChange={setTravelClass}
                          >
                            <SelectTrigger className="pl-10" id="class">
                              <SelectValue placeholder="Select class" />
                            </SelectTrigger>
                            <SelectContent>
                              {travelClasses.map((travelClass) => (
                                <SelectItem key={travelClass.id} value={travelClass.id}>
                                  {travelClass.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-5 sm:flex-row">
                      <div className="flex-1 space-y-2">
                        <Label htmlFor="quota">Quota</Label>
                        <div className="relative">
                          <User className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Select
                            value={quota}
                            onValueChange={setQuota}
                          >
                            <SelectTrigger className="pl-10" id="quota">
                              <SelectValue placeholder="Select quota" />
                            </SelectTrigger>
                            <SelectContent>
                              {quotas.map((quota) => (
                                <SelectItem key={quota.id} value={quota.id}>
                                  {quota.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="flex-1 flex items-end">
                        <div className="space-y-2 w-full flex flex-wrap justify-between items-center gap-4">
                          <div className="flex items-center space-x-2">
                            <Checkbox id="flexibleDate" />
                            <label
                              htmlFor="flexibleDate"
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              Flexible with date
                            </label>
                          </div>

                          <div className="flex items-center space-x-2">
                            <Checkbox id="divyangjan" />
                            <label
                              htmlFor="divyangjan"
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              Person with disability
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="flex justify-between bg-muted/30 p-6">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Info className="mr-2 h-4 w-4" />
                    <p>Train search shows best available options</p>
                  </div>
                  <Button className="gap-2">
                    <Search className="h-4 w-4" />
                    Find Trains
                  </Button>
                </CardFooter>
              </Tabs>
            </Card>

            <div className="mt-8 space-y-4 rounded-lg border bg-card p-6 text-card-foreground shadow">
              <h2 className="font-medium">Smart Tips for Booking Tickets</h2>
              <div className="space-y-3">
                <div className="flex items-start">
                  <span className="mr-3 rounded-full bg-primary/20 p-1 text-primary">
                    <CheckCircle2 className="h-5 w-5" />
                  </span>
                  <div>
                    <h3 className="text-sm font-medium">Best Time to Book</h3>
                    <p className="text-sm text-muted-foreground">Tickets usually open 120 days in advance. Book early morning for best availability.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <span className="mr-3 rounded-full bg-primary/20 p-1 text-primary">
                    <Sparkles className="h-5 w-5" />
                  </span>
                  <div>
                    <h3 className="text-sm font-medium">Tatkal Booking</h3>
                    <p className="text-sm text-muted-foreground">Tatkal bookings open at 10:00 AM for AC classes and 11:00 AM for non-AC classes, one day before journey.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <span className="mr-3 rounded-full bg-primary/20 p-1 text-primary">
                    <Clock className="h-5 w-5" />
                  </span>
                  <div>
                    <h3 className="text-sm font-medium">Waitlist Strategy</h3>
                    <p className="text-sm text-muted-foreground">GNWL (General Waitlist) has better chances of confirmation than RLWL (Remote Location Waitlist).</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <span className="mr-3 rounded-full bg-primary/20 p-1 text-primary">
                    <Train className="h-5 w-5" />
                  </span>
                  <div>
                    <h3 className="text-sm font-medium">Alternative Trains</h3>
                    <p className="text-sm text-muted-foreground">Consider trains with nearby stations as alternatives when your preferred train is full.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
