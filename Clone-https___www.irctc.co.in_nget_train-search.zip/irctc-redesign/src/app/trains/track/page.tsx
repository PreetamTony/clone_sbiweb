"use client";

import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  AlertCircle,
  Clock,
  MapPin,
  Search,
  Share2,
  Train,
  Calendar,
  Info,
  ArrowRight,
  Navigation,
  CheckCircle,
  RefreshCw,
} from "lucide-react";

// Define types for our data
interface Station {
  code: string;
  name: string;
  distance: string;
  scheduledArrival?: string;
  actualArrival?: string;
  scheduledDeparture?: string;
  actualDeparture?: string;
  status: string;
  delay?: string;
  date: string;
}

interface TrainLocation {
  trainNumber: string;
  trainName: string;
  status: string;
  lastUpdated: string;
  currentStation: string;
  currentStationName: string;
  nextStation: string;
  nextStationName: string;
  scheduledArrival: string;
  estimatedArrival: string;
  delay: string;
  totalDistance: string;
  coveredDistance: string;
  remainingDistance: string;
  progressPercentage: number;
  stations: Station[];
}

// Mock train location data
const mockTrainLocation: TrainLocation = {
  trainNumber: "12301",
  trainName: "Howrah - New Delhi Rajdhani Express",
  status: "Running on time",
  lastUpdated: "22-Mar-2025 14:23",
  currentStation: "GAYA",
  currentStationName: "Gaya Junction",
  nextStation: "PNBE",
  nextStationName: "Patna Junction",
  scheduledArrival: "15:30",
  estimatedArrival: "15:35",
  delay: "5 min",
  totalDistance: "1451 km",
  coveredDistance: "859 km",
  remainingDistance: "592 km",
  progressPercentage: 59,
  stations: [
    {
      code: "HWH",
      name: "Howrah Junction",
      distance: "0 km",
      scheduledDeparture: "16:55",
      actualDeparture: "16:55",
      status: "DEPARTED",
      date: "21-Mar-2025",
    },
    {
      code: "GAYA",
      name: "Gaya Junction",
      distance: "859 km",
      scheduledArrival: "01:19",
      actualArrival: "01:24",
      scheduledDeparture: "01:24",
      actualDeparture: "01:29",
      status: "DEPARTED",
      delay: "5 min",
      date: "22-Mar-2025",
    },
    {
      code: "PNBE",
      name: "Patna Junction",
      distance: "960 km",
      scheduledArrival: "03:35",
      scheduledDeparture: "03:45",
      status: "UPCOMING",
      date: "22-Mar-2025",
    },
    {
      code: "MGS",
      name: "Mughal Sarai Junction",
      distance: "1149 km",
      scheduledArrival: "05:55",
      scheduledDeparture: "06:00",
      status: "UPCOMING",
      date: "22-Mar-2025",
    },
    {
      code: "CNB",
      name: "Kanpur Central",
      distance: "1331 km",
      scheduledArrival: "08:25",
      scheduledDeparture: "08:35",
      status: "UPCOMING",
      date: "22-Mar-2025",
    },
    {
      code: "NDLS",
      name: "New Delhi",
      distance: "1451 km",
      scheduledArrival: "09:55",
      status: "UPCOMING",
      date: "22-Mar-2025",
    },
  ]
};

export default function TrackTrainPage() {
  const [trainNumber, setTrainNumber] = useState("");
  const [isTracking, setIsTracking] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [activeTab, setActiveTab] = useState("trainNumber");

  // Mock function for demonstration
  const handleTrackTrain = () => {
    if (!trainNumber || trainNumber.length < 5) {
      alert("Please enter a valid train number");
      return;
    }

    setIsTracking(true);

    // Simulate API call
    setTimeout(() => {
      setIsTracking(false);
      setShowResult(true);
    }, 1500);
  };

  // Function to get status color
  const getStatusColor = (status: string): string => {
    switch (status) {
      case "DEPARTED":
        return "bg-green-100 text-green-800";
      case "ARRIVED":
        return "bg-blue-100 text-blue-800";
      case "UPCOMING":
        return "bg-gray-100 text-gray-800";
      case "DELAYED":
        return "bg-amber-100 text-amber-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <MainLayout>
      <section className="bg-gradient-to-b from-blue-50 to-white py-8 md:py-12">
        <div className="container">
          <div className="mx-auto max-w-3xl">
            <h1 className="text-center text-3xl font-bold tracking-tight md:text-4xl">Track Your Train</h1>
            <p className="mt-3 text-center text-muted-foreground">
              Get real-time location updates and status information for your train
            </p>

            <Card className="mt-8">
              <Tabs defaultValue="trainNumber" onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="trainNumber">By Train Number</TabsTrigger>
                  <TabsTrigger value="pnr">By PNR</TabsTrigger>
                </TabsList>

                <TabsContent value="trainNumber">
                  <CardHeader>
                    <CardTitle>Track Using Train Number</CardTitle>
                    <CardDescription>
                      Enter train number to get its current running status
                    </CardDescription>
                  </CardHeader>

                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="trainNumber">Train Number</Label>
                        <div className="relative">
                          <Train className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input
                            id="trainNumber"
                            placeholder="Enter train number (e.g. 12301)"
                            className="pl-10"
                            value={trainNumber}
                            onChange={(e) => setTrainNumber(e.target.value.replace(/[^0-9]/g, ''))}
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </TabsContent>

                <TabsContent value="pnr">
                  <CardHeader>
                    <CardTitle>Track Using PNR</CardTitle>
                    <CardDescription>
                      Enter your PNR number to track the train's current location
                    </CardDescription>
                  </CardHeader>

                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="pnr">PNR Number</Label>
                        <div className="relative">
                          <Train className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input
                            id="pnr"
                            placeholder="Enter 10 digit PNR number"
                            className="pl-10"
                            onChange={(e) => {}}
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </TabsContent>

                <CardFooter className="flex justify-between border-t px-6 py-4">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Info className="mr-2 h-4 w-4" />
                    <p>Updates every 5-10 minutes</p>
                  </div>
                  <Button
                    className="gap-2"
                    onClick={handleTrackTrain}
                    disabled={isTracking || (activeTab === "trainNumber" && trainNumber.length < 5)}
                  >
                    {isTracking ? (
                      <>
                        <RefreshCw className="h-4 w-4 animate-spin" />
                        Tracking...
                      </>
                    ) : (
                      <>
                        <Navigation className="h-4 w-4" />
                        Track Train
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Tabs>
            </Card>

            {showResult && (
              <div className="mt-8 space-y-6">
                <Card>
                  <CardHeader className="pb-4">
                    <div className="flex flex-wrap items-center justify-between gap-4">
                      <div>
                        <CardTitle>{mockTrainLocation.trainName}</CardTitle>
                        <CardDescription>Train No: {mockTrainLocation.trainNumber}</CardDescription>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant={mockTrainLocation.delay === "0 min" ? "default" : "outline"} className="gap-1">
                          <Clock className="h-3 w-3" />
                          {mockTrainLocation.delay === "0 min" ? "On Time" : `Delayed by ${mockTrainLocation.delay}`}
                        </Badge>
                        <Button variant="outline" size="icon" className="h-8 w-8">
                          <Share2 className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={handleTrackTrain}>
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-6">
                    <div className="flex flex-col sm:flex-row justify-between gap-4 border rounded-lg p-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Current Location</p>
                        <div className="mt-1 flex items-center gap-2">
                          <MapPin className="h-5 w-5 text-primary" />
                          <span className="font-medium">{mockTrainLocation.currentStationName}</span>
                          <span className="text-sm text-muted-foreground">({mockTrainLocation.currentStation})</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Last Updated</p>
                        <div className="mt-1 flex items-center gap-2">
                          <Clock className="h-5 w-5 text-primary" />
                          <span>{mockTrainLocation.lastUpdated}</span>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <div className="mb-4 flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Journey Progress</h3>
                          <p className="text-sm text-muted-foreground">
                            {mockTrainLocation.coveredDistance} of {mockTrainLocation.totalDistance} completed
                          </p>
                        </div>
                        <Badge variant="outline">{mockTrainLocation.progressPercentage}%</Badge>
                      </div>

                      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full bg-primary"
                          style={{ width: `${mockTrainLocation.progressPercentage}%` }}
                        ></div>
                      </div>

                      <div className="mt-6">
                        <div className="flex items-center justify-between text-sm">
                          <div className="text-center">
                            <div className="font-medium">{mockTrainLocation.stations[0].code}</div>
                            <div className="text-xs text-muted-foreground">Origin</div>
                          </div>

                          <div className="text-center">
                            <div className="font-medium">{mockTrainLocation.currentStation}</div>
                            <div className="text-xs text-muted-foreground">Current</div>
                          </div>

                          <div className="text-center">
                            <div className="font-medium">{mockTrainLocation.stations[mockTrainLocation.stations.length - 1].code}</div>
                            <div className="text-xs text-muted-foreground">Destination</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="mb-4 font-medium">Train Route & Status</h3>
                      <div className="space-y-5 p-1">
                        {mockTrainLocation.stations.map((station, index) => (
                          <div key={station.code} className="flex">
                            <div className="mr-4 flex flex-col items-center">
                              <div className={`flex h-8 w-8 items-center justify-center rounded-full border-2 ${
                                station.status === "DEPARTED"
                                  ? "border-green-500 bg-green-50"
                                  : station.code === mockTrainLocation.currentStation
                                    ? "border-blue-500 bg-blue-50"
                                    : "border-gray-200 bg-gray-50"
                              }`}>
                                {station.status === "DEPARTED" ? (
                                  <CheckCircle className="h-4 w-4 text-green-500" />
                                ) : station.code === mockTrainLocation.currentStation ? (
                                  <Train className="h-4 w-4 text-blue-500" />
                                ) : (
                                  <div className="h-2 w-2 rounded-full bg-gray-300"></div>
                                )}
                              </div>
                              {index < mockTrainLocation.stations.length - 1 && (
                                <div className={`h-full w-0.5 ${
                                  station.status === "DEPARTED" ? "bg-green-200" : "bg-gray-200"
                                }`}></div>
                              )}
                            </div>

                            <div className="flex-1 pb-5">
                              <div className="flex items-start justify-between">
                                <div>
                                  <p className="font-medium">{station.name}</p>
                                  <p className="text-sm text-muted-foreground">{station.code} • {station.distance}</p>
                                </div>
                                <Badge className={`${getStatusColor(station.status)}`}>
                                  {station.status}
                                </Badge>
                              </div>

                              <div className="mt-1 text-sm">
                                {station.scheduledArrival && (
                                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                                    <span>
                                      <span className="text-muted-foreground">Scheduled Arrival: </span>
                                      {station.scheduledArrival}
                                    </span>

                                    {station.actualArrival && (
                                      <span>
                                        <span className="text-muted-foreground">Actual: </span>
                                        {station.actualArrival}
                                      </span>
                                    )}
                                  </div>
                                )}

                                {station.scheduledDeparture && (
                                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                                    <span>
                                      <span className="text-muted-foreground">Scheduled Departure: </span>
                                      {station.scheduledDeparture}
                                    </span>

                                    {station.actualDeparture && (
                                      <span>
                                        <span className="text-muted-foreground">Actual: </span>
                                        {station.actualDeparture}
                                      </span>
                                    )}
                                  </div>
                                )}

                                {station.delay && (
                                  <div className="mt-1 text-amber-600">
                                    Delayed by {station.delay}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between rounded-lg border bg-muted/30 p-4">
                      <div className="text-sm">
                        <span className="text-muted-foreground">Next Station: </span>
                        <span className="font-medium">{mockTrainLocation.nextStationName}</span>
                      </div>
                      <div className="text-sm">
                        <span className="text-muted-foreground">ETA: </span>
                        <span className="font-medium">{mockTrainLocation.estimatedArrival}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="text-center">
                  <h3 className="mb-3 text-lg font-medium">Other Services</h3>
                  <div className="flex flex-wrap justify-center gap-2">
                    <Button variant="outline" size="sm" asChild>
                      <a href="/trains/pnr-status">Check PNR Status</a>
                    </Button>
                    <Button variant="outline" size="sm" asChild>
                      <a href="/trains/booking">Book Tickets</a>
                    </Button>
                    <Button variant="outline" size="sm" asChild>
                      <a href="/trains/schedule">Train Schedule</a>
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
