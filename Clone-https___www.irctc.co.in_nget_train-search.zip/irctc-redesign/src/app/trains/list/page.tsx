"use client";

import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, Clock, Filter, Search, Shield, ShieldAlert, Sliders, Train, ZoomIn } from "lucide-react";

// Define types for our data
interface TravelClass {
  code: string;
  available: number;
  fare: number;
  status: string;
}

interface TrainData {
  id: string;
  name: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  departureStation: string;
  departureStationName: string;
  arrivalStation: string;
  arrivalStationName: string;
  travelClasses: TravelClass[];
  pantry: boolean;
  runsOn: string[];
  journeyDate: string;
}

// Mock train data
const mockTrains: TrainData[] = [
  {
    id: "12301",
    name: "Howrah - New Delhi Rajdhani Express",
    departureTime: "16:55",
    arrivalTime: "09:55",
    duration: "17h 00m",
    departureStation: "NDLS",
    departureStationName: "New Delhi",
    arrivalStation: "HWH",
    arrivalStationName: "Howrah Jn",
    travelClasses: [
      { code: "1A", available: 15, fare: 6780, status: "Available" },
      { code: "2A", available: 42, fare: 3780, status: "Available" },
      { code: "3A", available: 84, fare: 2490, status: "Available" },
    ],
    pantry: true,
    runsOn: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    journeyDate: "29 Mar 2025",
  },
  {
    id: "12303",
    name: "Poorva Express",
    departureTime: "20:35",
    arrivalTime: "15:50",
    duration: "19h 15m",
    departureStation: "NDLS",
    departureStationName: "New Delhi",
    arrivalStation: "HWH",
    arrivalStationName: "Howrah Jn",
    travelClasses: [
      { code: "SL", available: 120, fare: 865, status: "Available" },
      { code: "3A", available: 0, fare: 2310, status: "Waitlist" },
      { code: "2A", available: 8, fare: 3330, status: "Available" },
    ],
    pantry: true,
    runsOn: ["Mon", "Wed", "Fri", "Sun"],
    journeyDate: "29 Mar 2025",
  },
  {
    id: "12305",
    name: "Howrah - Delhi Duronto Express",
    departureTime: "08:05",
    arrivalTime: "03:50",
    duration: "19h 45m",
    departureStation: "NDLS",
    departureStationName: "New Delhi",
    arrivalStation: "HWH",
    arrivalStationName: "Howrah Jn",
    travelClasses: [
      { code: "3A", available: 36, fare: 2385, status: "Available" },
      { code: "2A", available: 4, fare: 3420, status: "RAC" },
      { code: "1A", available: 0, fare: 6430, status: "Waitlist" },
    ],
    pantry: true,
    runsOn: ["Tue", "Thu", "Sat"],
    journeyDate: "30 Mar 2025",
  },
  {
    id: "12259",
    name: "Sealdah - New Delhi Duronto Express",
    departureTime: "13:15",
    arrivalTime: "10:45",
    duration: "21h 30m",
    departureStation: "NDLS",
    departureStationName: "New Delhi",
    arrivalStation: "SDAH",
    arrivalStationName: "Sealdah",
    travelClasses: [
      { code: "3A", available: 65, fare: 2350, status: "Available" },
      { code: "2A", available: 28, fare: 3380, status: "Available" },
      { code: "1A", available: 12, fare: 6330, status: "Available" },
    ],
    pantry: true,
    runsOn: ["Mon", "Wed", "Fri"],
    journeyDate: "29 Mar 2025",
  },
  {
    id: "13007",
    name: "Udyan Abha Toofan Express",
    departureTime: "23:50",
    arrivalTime: "21:20",
    duration: "45h 30m",
    departureStation: "NDLS",
    departureStationName: "New Delhi",
    arrivalStation: "HWH",
    arrivalStationName: "Howrah Jn",
    travelClasses: [
      { code: "SL", available: 220, fare: 785, status: "Available" },
      { code: "3A", available: 48, fare: 2120, status: "Available" },
      { code: "2S", available: 180, fare: 505, status: "Available" },
    ],
    pantry: false,
    runsOn: ["Mon", "Thu", "Sat"],
    journeyDate: "28 Mar 2025",
  },
];

const travelClassNames: Record<string, string> = {
  "1A": "First AC",
  "2A": "Second AC",
  "3A": "Third AC",
  "SL": "Sleeper",
  "2S": "Second Sitting",
  "CC": "AC Chair Car",
  "EC": "Exec. Chair Car",
};

export default function TrainListPage() {
  const [selectedDate, setSelectedDate] = useState("29 Mar 2025");
  const [selectedClass, setSelectedClass] = useState("all");
  const [sortBy, setSortBy] = useState("departure");

  // Filtered trains based on selections
  const filteredTrains = mockTrains.filter(train => {
    if (selectedDate !== "all" && train.journeyDate !== selectedDate) {
      return false;
    }

    if (selectedClass !== "all") {
      const hasClass = train.travelClasses.some(c => c.code === selectedClass);
      if (!hasClass) return false;
    }

    return true;
  });

  // Sort trains based on selected criteria
  const sortedTrains = [...filteredTrains].sort((a, b) => {
    if (sortBy === "departure") {
      return a.departureTime.localeCompare(b.departureTime);
    } else if (sortBy === "arrival") {
      return a.arrivalTime.localeCompare(b.arrivalTime);
    } else if (sortBy === "duration") {
      return a.duration.localeCompare(b.duration);
    }
    return 0;
  });

  const getStatusColor = (status: string): string => {
    switch (status) {
      case "Available":
        return "text-green-600 bg-green-50";
      case "RAC":
        return "text-amber-600 bg-amber-50";
      case "Waitlist":
        return "text-red-600 bg-red-50";
      default:
        return "text-muted-foreground bg-muted";
    }
  };

  return (
    <MainLayout>
      <section className="py-6">
        <div className="container">
          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-2xl font-bold sm:text-3xl">Delhi to Kolkata</h1>
              <p className="text-muted-foreground">Showing trains for 29 Mar 2025 • 5 Trains Found</p>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" className="gap-2">
                <Filter className="h-4 w-4" />
                Modify Search
              </Button>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="h-9 w-auto">
                  <Sliders className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Sort By" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="departure">Departure Time</SelectItem>
                  <SelectItem value="arrival">Arrival Time</SelectItem>
                  <SelectItem value="duration">Duration</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-4 lg:gap-8">
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Filters</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    <h3 className="text-sm font-medium">Journey Date</h3>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant={selectedDate === "28 Mar 2025" ? "default" : "outline"}
                        size="sm"
                        className="h-auto py-1"
                        onClick={() => setSelectedDate("28 Mar 2025")}
                      >
                        28 Mar
                      </Button>
                      <Button
                        variant={selectedDate === "29 Mar 2025" ? "default" : "outline"}
                        size="sm"
                        className="h-auto py-1"
                        onClick={() => setSelectedDate("29 Mar 2025")}
                      >
                        29 Mar
                      </Button>
                      <Button
                        variant={selectedDate === "30 Mar 2025" ? "default" : "outline"}
                        size="sm"
                        className="h-auto py-1"
                        onClick={() => setSelectedDate("30 Mar 2025")}
                      >
                        30 Mar
                      </Button>
                      <Button
                        variant={selectedDate === "31 Mar 2025" ? "default" : "outline"}
                        size="sm"
                        className="h-auto py-1"
                        onClick={() => setSelectedDate("31 Mar 2025")}
                      >
                        31 Mar
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-sm font-medium">Travel Class</h3>
                    <div className="space-y-2">
                      {Object.entries(travelClassNames).map(([code, name]) => (
                        <Button
                          key={code}
                          variant={selectedClass === code ? "default" : "outline"}
                          size="sm"
                          className="mr-2 mb-2 h-auto py-1"
                          onClick={() => setSelectedClass(code)}
                        >
                          {code} - {name}
                        </Button>
                      ))}
                      <Button
                        variant={selectedClass === "all" ? "default" : "outline"}
                        size="sm"
                        className="h-auto py-1"
                        onClick={() => setSelectedClass("all")}
                      >
                        All Classes
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-sm font-medium">Departure Time</h3>
                    <div className="space-y-2">
                      <Button variant="outline" size="sm" className="mr-2 mb-2 h-auto py-1">00:00 - 06:00</Button>
                      <Button variant="outline" size="sm" className="mr-2 mb-2 h-auto py-1">06:00 - 12:00</Button>
                      <Button variant="outline" size="sm" className="mr-2 mb-2 h-auto py-1">12:00 - 18:00</Button>
                      <Button variant="outline" size="sm" className="mr-2 mb-2 h-auto py-1">18:00 - 23:59</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-3">
              <div className="space-y-4">
                {sortedTrains.length > 0 ? (
                  sortedTrains.map((train) => (
                    <Card key={train.id} className="overflow-hidden">
                      <CardHeader className="bg-muted/30 py-4">
                        <div className="flex flex-wrap items-center justify-between gap-4">
                          <div className="flex items-center gap-3">
                            <Train className="h-5 w-5 text-primary" />
                            <div>
                              <h3 className="font-medium">{train.name}</h3>
                              <p className="text-sm text-muted-foreground">{train.id} • Runs on: {train.runsOn.join(", ")}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {train.pantry && (
                              <Badge variant="outline" className="gap-1">
                                <CheckCircle className="h-3 w-3" /> Pantry
                              </Badge>
                            )}
                            <Badge variant="outline" className="gap-1">
                              <Clock className="h-3 w-3" /> {train.duration}
                            </Badge>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="mb-4 flex flex-col justify-between gap-4 md:flex-row">
                          <div className="flex justify-between md:justify-start md:gap-16">
                            <div className="text-center">
                              <p className="text-lg font-medium">{train.departureTime}</p>
                              <p className="text-sm text-muted-foreground">{train.departureStation}</p>
                              <p className="text-xs">{train.departureStationName}</p>
                            </div>
                            <div className="px-4">
                              <div className="flex flex-col items-center">
                                <p className="text-sm text-muted-foreground">{train.duration}</p>
                                <div className="relative w-20 border-t border-dashed">
                                  <Train className="absolute -bottom-2 left-1/2 h-4 w-4 -translate-x-1/2 text-primary" />
                                </div>
                              </div>
                            </div>
                            <div className="text-center">
                              <p className="text-lg font-medium">{train.arrivalTime}</p>
                              <p className="text-sm text-muted-foreground">{train.arrivalStation}</p>
                              <p className="text-xs">{train.arrivalStationName}</p>
                            </div>
                          </div>

                          <div className="flex flex-wrap justify-end gap-4">
                            {train.travelClasses.map((travelClass) => (
                              <div key={travelClass.code} className="rounded-md border p-3 text-center">
                                <p className="text-sm font-medium">{travelClass.code}</p>
                                <p className={`mt-1 text-xs rounded-full px-2 py-0.5 ${getStatusColor(travelClass.status)}`}>
                                  {travelClass.status}
                                </p>
                                <p className="mt-1 text-sm">₹{travelClass.fare}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between bg-muted/20 py-3">
                        <Button variant="ghost" size="sm" className="gap-1">
                          <ZoomIn className="h-4 w-4" />
                          Train Details
                        </Button>
                        <Button size="sm">Book Now</Button>
                      </CardFooter>
                    </Card>
                  ))
                ) : (
                  <Card className="p-8 text-center">
                    <ShieldAlert className="mx-auto h-12 w-12 text-muted-foreground" />
                    <h3 className="mt-4 text-lg font-medium">No Trains Found</h3>
                    <p className="mt-2 text-muted-foreground">
                      No trains match your search criteria. Try changing your filters or search for a different date.
                    </p>
                    <Button className="mt-4">Modify Search</Button>
                  </Card>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
