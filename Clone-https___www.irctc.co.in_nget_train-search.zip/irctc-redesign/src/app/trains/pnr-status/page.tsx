"use client";

import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Train, Clock, Calendar, User, MapPin, AlertCircle, Smartphone } from "lucide-react";

export default function PnrStatusPage() {
  const [pnrNumber, setPnrNumber] = useState("");
  const [isChecking, setIsChecking] = useState(false);
  const [showResult, setShowResult] = useState(false);

  // This is a mock function for demonstration
  const handleCheckPnr = () => {
    if (pnrNumber.length !== 10) {
      alert("Please enter a valid 10-digit PNR number");
      return;
    }

    setIsChecking(true);

    // Simulate API call
    setTimeout(() => {
      setIsChecking(false);
      setShowResult(true);
    }, 1500);
  };

  return (
    <MainLayout>
      <section className="bg-gradient-to-b from-blue-50 to-white py-8 md:py-12">
        <div className="container">
          <div className="mx-auto max-w-3xl">
            <h1 className="text-center text-3xl font-bold tracking-tight md:text-4xl">PNR Status</h1>
            <p className="mt-3 text-center text-muted-foreground">
              Check the current status of your train ticket by entering the PNR number
            </p>

            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Enter PNR Details</CardTitle>
                <CardDescription>
                  Your 10-digit PNR number is printed on the top left corner of your ticket
                </CardDescription>
              </CardHeader>

              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="pnr">PNR Number</Label>
                    <div className="relative">
                      <Train className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                      <Input
                        id="pnr"
                        placeholder="Enter 10 digit PNR number"
                        className="pl-10"
                        value={pnrNumber}
                        onChange={(e) => setPnrNumber(e.target.value.replace(/[^0-9]/g, '').slice(0, 10))}
                        maxLength={10}
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2 rounded-lg bg-muted/50 p-3 text-sm">
                    <AlertCircle className="h-5 w-5 text-primary" />
                    <p>Make sure to enter the correct PNR number for accurate status.</p>
                  </div>
                </div>
              </CardContent>

              <CardFooter className="flex justify-end">
                <Button
                  className="gap-2"
                  onClick={handleCheckPnr}
                  disabled={isChecking || pnrNumber.length !== 10}
                >
                  {isChecking ? (
                    <>
                      <span className="animate-spin">⏳</span>
                      Checking...
                    </>
                  ) : (
                    <>
                      <Search className="h-4 w-4" />
                      Check Status
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>

            {showResult && (
              <Card className="mt-8">
                <CardHeader className="bg-primary/5">
                  <div className="flex justify-between items-center">
                    <CardTitle>PNR Status: Confirmed</CardTitle>
                    <div className="px-3 py-1 rounded-full bg-green-100 text-green-800 text-sm font-medium">
                      CNF
                    </div>
                  </div>
                  <CardDescription>PNR Number: {pnrNumber}</CardDescription>
                </CardHeader>

                <CardContent className="p-6">
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div className="flex flex-col gap-1">
                        <div className="text-sm text-muted-foreground">Train Number & Name</div>
                        <div className="font-medium">12301 • Howrah - New Delhi Rajdhani Express</div>
                      </div>

                      <div className="flex flex-col gap-1">
                        <div className="text-sm text-muted-foreground">Travel Date</div>
                        <div className="font-medium">Sat, 29 Mar 2025</div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-6 pt-2 sm:flex-row">
                      <div className="flex-1">
                        <div className="flex items-start">
                          <MapPin className="mr-3 mt-1 h-5 w-5 text-primary" />
                          <div>
                            <div className="text-lg font-medium">NDLS</div>
                            <div className="text-sm">New Delhi</div>
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <Clock className="h-4 w-4" />
                              Departure: 16:55
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center">
                        <div className="relative w-full">
                          <div className="flex items-center justify-center">
                            <div className="relative h-0.5 w-16 bg-primary sm:w-24">
                              <Train className="absolute -bottom-2 left-1/2 h-5 w-5 -translate-x-1/2 text-primary" />
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex-1">
                        <div className="flex items-start">
                          <MapPin className="mr-3 mt-1 h-5 w-5 text-primary" />
                          <div>
                            <div className="text-lg font-medium">HWH</div>
                            <div className="text-sm">Howrah Junction</div>
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <Clock className="h-4 w-4" />
                              Arrival: 09:55 (+1 day)
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h3 className="mb-2 font-medium">Passenger Details</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between border-b pb-2">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span>Passenger 1</span>
                          </div>
                          <div className="flex items-center gap-4">
                            <div>
                              <span className="text-sm text-muted-foreground">Coach: </span>
                              <span>A1</span>
                            </div>
                            <div>
                              <span className="text-sm text-muted-foreground">Berth: </span>
                              <span>17 (LB)</span>
                            </div>
                            <div className="px-2 py-1 rounded-full bg-green-100 text-green-800 text-xs font-medium">
                              Confirmed
                            </div>
                          </div>
                        </div>

                        <div className="flex justify-between border-b pb-2">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span>Passenger 2</span>
                          </div>
                          <div className="flex items-center gap-4">
                            <div>
                              <span className="text-sm text-muted-foreground">Coach: </span>
                              <span>A1</span>
                            </div>
                            <div>
                              <span className="text-sm text-muted-foreground">Berth: </span>
                              <span>18 (UB)</span>
                            </div>
                            <div className="px-2 py-1 rounded-full bg-green-100 text-green-800 text-xs font-medium">
                              Confirmed
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border bg-muted/30 p-4">
                      <h3 className="font-medium">Additional Information</h3>
                      <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                        <div>
                          <span className="text-sm text-muted-foreground">Class: </span>
                          <span>AC 2-Tier (2A)</span>
                        </div>
                        <div>
                          <span className="text-sm text-muted-foreground">Chart Status: </span>
                          <span>Chart Prepared</span>
                        </div>
                        <div>
                          <span className="text-sm text-muted-foreground">Total Fare: </span>
                          <span>₹3,780</span>
                        </div>
                        <div>
                          <span className="text-sm text-muted-foreground">Distance: </span>
                          <span>1,451 km</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="flex gap-4">
                  <Button variant="outline" className="flex-1 gap-2">
                    <Smartphone className="h-4 w-4" />
                    SMS Status
                  </Button>
                  <Button className="flex-1 gap-2">
                    Track Train
                  </Button>
                </CardFooter>
              </Card>
            )}

            <div className="mt-8 text-center">
              <h3 className="text-lg font-medium">Other Services</h3>
              <div className="mt-4 flex flex-wrap justify-center gap-4">
                <Button variant="outline" asChild>
                  <a href="/trains/booking">Book Train Tickets</a>
                </Button>
                <Button variant="outline" asChild>
                  <a href="/trains/track">Track Your Train</a>
                </Button>
                <Button variant="outline" asChild>
                  <a href="/trains/schedule">Train Schedules</a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
