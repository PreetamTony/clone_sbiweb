# IRCTC Redesign

This project is a modern redesign of the IRCTC (Indian Railway Catering and Tourism Corporation) website with a cleaner, more aesthetic UI.

## Features

- **Modern UI**: Clean, responsive design with improved aesthetics and usability
- **Train Booking**: Simplified booking flow with intuitive forms
- **PNR Status**: Check PNR status with a modern results display
- **Train List**: Enhanced train search results with filters and sorting
- **Train Tracking**: Live train tracking with journey progress visualization
- **User Authentication**: Improved login and signup experience

## Tech Stack

- **Framework**: Next.js 15
- **UI Components**: Shadcn UI
- **Styling**: Tailwind CSS
- **Deployment**: Netlify

## Pages

1. **Landing Page**: Main homepage with train booking form and services
2. **Login/Signup**: User authentication screens
3. **Train Booking**: Detailed booking form with options
4. **Train List**: Search results displaying available trains
5. **Track Your Train**: Live train tracking with status updates

## Getting Started

```bash
# Install dependencies
bun install

# Start development server
bun run dev

# Build for production
bun run build
```

## Design Principles

- **Simplicity**: Reducing clutter and focusing on core functionality
- **Accessibility**: Ensuring the site works for everyone
- **Performance**: Fast loading times and smooth interactions
- **Mobile-First**: Fully responsive design that works on all devices

## Future Improvements

- Integration with real API endpoints
- Advanced seat selection interface
- Multilingual support
- Dark mode toggle
- Native mobile apps (iOS/Android)
